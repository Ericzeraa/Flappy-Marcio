function ajustarNome(nome) {
  return nome.trim().replace(/\s+/g, " ").slice(0, 24);
}

function nomeValido(nome) {
  return ajustarNome(nome).length >= 2;
}

function modoAtual() {
  return dificuldades[dificuldade] || dificuldades.normal;
}

function skinDados() {
  return skins[skinSelecionada] || skins.classica;
}

function atualizarPerfilRecolhido() {
  if (!areaPerfil || !btnAlternarPerfil) return;
  areaPerfil.classList.toggle("retraido", perfilRecolhido);
  btnAlternarPerfil.textContent = perfilRecolhido ? "Abrir login" : "Recolher";
  btnAlternarPerfil.setAttribute(
    "aria-expanded",
    perfilRecolhido ? "false" : "true",
  );
}

function alternarPerfil() {
  perfilRecolhido = !perfilRecolhido;
  localStorage.setItem(
    "flappy_marcio_perfil_retraido",
    perfilRecolhido ? "1" : "0",
  );
  atualizarPerfilRecolhido();
}

function skinLiberada(skin, perfil) {
  const dados = skins[skin] || skins.classica;
  if (skin === "classica") return true;
  if (!perfil) return false;
  return (
    Number(perfil.melhor || 0) >= Number(dados.pontos || 0) &&
    Number(perfil.fase || 1) >= Number(dados.fase || 1) &&
    Number(perfil.partidas || 0) >= Number(dados.partidas || 0)
  );
}

function atualizarPainelConquistas(lista = []) {
  conquistasLiberadas = new Set(
    (Array.isArray(lista) ? lista : []).map((item) => item.codigo),
  );
  if (statusConquistas)
    statusConquistas.textContent = `${conquistasLiberadas.size}/${conquistasCatalogo.length}`;
  if (!conquistasGrade) return;
  conquistasGrade.querySelectorAll(".conquista-item").forEach((item) => {
    const liberada = conquistasLiberadas.has(item.dataset.conquista);
    item.classList.toggle("bloqueada", !liberada);
    item.classList.toggle("liberada", liberada);
  });
}

function destacarConquistas(lista = []) {
  if (!Array.isArray(lista) || !lista.length) return;
  lista.forEach((item, indice) => {
    setTimeout(() => {
      const toast = document.createElement("div");
      toast.className = "toast-conquista";
      toast.innerHTML = `<strong>Conquista liberada</strong><span>${escaparTexto(item.titulo)}</span>`;
      document.body.appendChild(toast);
      setTimeout(() => toast.classList.add("saindo"), 2700);
      setTimeout(() => toast.remove(), 3300);
    }, indice * 360);
  });
}

function atualizarSkins(perfil = perfilAtual) {
  perfilAtual = perfil;
  if (!skinLiberada(skinSelecionada, perfilAtual)) skinSelecionada = "classica";
  localStorage.setItem("flappy_marcio_skin", skinSelecionada);
  if (skinAtual) skinAtual.textContent = skinDados().nome || "Clássica";
  document.querySelectorAll(".skin-opcao").forEach((botao) => {
    const chave = botao.dataset.skin || "classica";
    const liberada = skinLiberada(chave, perfilAtual);
    botao.classList.toggle("ativa", chave === skinSelecionada);
    botao.classList.toggle("bloqueada", !liberada);
    botao.title = liberada ? "Selecionar skin" : "Bloqueada";
  });
}

function faseDoJogo() {
  return Math.max(
    1,
    Math.floor(pontos / Number(config.pontos_por_fase || 6)) + 1,
  );
}

function velocidadeAtual() {
  const modo = modoAtual();
  const base =
    Number(config.velocidade_inicial || 4.2) * Number(modo.vel || 1);
  const aumento = Number(config.aumento_fase || 0.34);
  const maximo =
    Number(config.velocidade_maxima || 6.4) + Number(modo.max || 0);
  const calculada = Math.min(maximo, base + (faseDoJogo() - 1) * aumento);
  return focoAtivo > 0 ? Math.max(base, calculada - 0.55) : calculada;
}

function multiplicadorVelocidade() {
  return velocidadeAtual() / Number(config.velocidade_inicial || 4.2);
}

function aberturaAtual() {
  const modo = modoAtual();
  const inicial =
    Number(config.abertura_inicial || 210) + Number(modo.abertura || 0);
  const minima =
    Number(config.abertura_minima || 168) + Number(modo.abertura || 0) * 0.5;
  return Math.max(minima, inicial - (faseDoJogo() - 1) * 5.5);
}

function intervaloCanos() {
  return Math.max(58, 88 - (faseDoJogo() - 1) * 3);
}

function amplitudeCano() {
  if (faseDoJogo() >= 7) return 16;
  if (faseDoJogo() >= 5) return 11;
  if (faseDoJogo() >= 4) return 6;
  return 0;
}

function progressoFase() {
  const passo = Number(config.pontos_por_fase || 6);
  return (pontos % passo) / passo;
}

function proximaFase() {
  return faseDoJogo() * Number(config.pontos_por_fase || 6);
}

function mostrarMensagem(texto, ok = false) {
  mensagemNome.textContent = texto;
  mensagemNome.classList.toggle("ok", ok);
}

function atualizarDificuldadeTela() {
  document.querySelectorAll(".dificuldade-opcao").forEach((botao) => {
    botao.classList.toggle("ativa", botao.dataset.dificuldade === dificuldade);
  });
  const nome = modoAtual().nome || "Normal";
  dificuldadeAtual.textContent = nome;
  hudDificuldade.textContent = nome;
}

function atualizarPlacarTela() {
  faseAtual.textContent = faseDoJogo();
  velocidadeHud.textContent = `${multiplicadorVelocidade().toFixed(1)}x`;

  if (estado === "jogando" && faseDoJogo() > faseAnterior) {
    faseAnterior = faseDoJogo();
    avisoJogo = `Fase ${faseAnterior}: mais velocidade`;
    criarParticulas(16, "#ffe66d", passaro.x + 35, passaro.y + 30);
  }
}

function definirJogador(dados) {
  if (!dados || !dados.jogador) {
    jogador = "";
    jogadorLogado = false;
    nomeAtual.textContent = "Visitante";
    if (perfilMinimoNome) perfilMinimoNome.textContent = "Visitante";
    statusJogador.textContent = "Visitante";
    if (btnSairJogador) btnSairJogador.classList.add("escondido");
    if (abasAcesso) abasAcesso.classList.remove("conta-logada");
    preencherPerfil(null);
    atualizarResumoJogador(0, null, [], null);
    atualizarPainelConquistas([]);
    atualizarDicaFlutuante();
    return;
  }

  jogador = ajustarNome(dados.jogador.nome || "");
  jogadorLogado = true;
  nomeAtual.textContent = jogador || "Jogador";
  if (perfilMinimoNome) perfilMinimoNome.textContent = jogador || "Jogador";
  statusJogador.textContent = "Logado";
  if (usuarioLogin) usuarioLogin.value = jogador;
  if (btnSairJogador) btnSairJogador.classList.remove("escondido");
  if (abasAcesso) abasAcesso.classList.add("conta-logada");
  mostrarMensagem("Conta ativa. Pressione espaço para começar.", true);
  atualizarResumoJogador(
    dados.recorde || (dados.perfil ? dados.perfil.melhor : 0),
    dados.posicao || null,
    dados.conquistas || [],
    dados.perfil || null,
  );
  atualizarPainelConquistas(dados.conquistas || []);
  if (dados.jogador.skin && skins[dados.jogador.skin]) {
    skinSelecionada = dados.jogador.skin;
    localStorage.setItem("flappy_marcio_skin", skinSelecionada);
    atualizarSkins(dados.perfil || null);
  }
  atualizarDicaFlutuante();
}

function criarDadosApi(acao) {
  const dados = new FormData();
  dados.append("acao", acao);
  if (window.CSRF_TOKEN) dados.append("csrf_token", window.CSRF_TOKEN);
  return dados;
}

async function enviarAcesso(acao, usuario, senha) {
  const dados = criarDadosApi(acao);
  dados.append("usuario", ajustarNome(usuario).toLowerCase());
  dados.append("senha", senha);
  const resposta = await fetch("sistema/requisicoes/jogo.php", {
    method: "POST",
    body: dados,
  });
  const retorno = await resposta.json();
  if (!retorno.ok)
    throw new Error(retorno.mensagem || "Não consegui acessar agora.");
  definirJogador(retorno);
  carregarRanking();
}

async function carregarSessao() {
  try {
    const resposta = await fetch("sistema/requisicoes/jogo.php?acao=sessao");
    const retorno = await resposta.json();
    if (retorno.ok && retorno.logado) definirJogador(retorno);
    else definirJogador(null);
  } catch (erro) {
    definirJogador(null);
  }
}

async function tentarComecar() {
  if (!jogadorLogado) {
    mostrarMensagem(
      "Entre ou crie uma conta para jogar e salvar seu progresso.",
    );
    perfilRecolhido = false;
    localStorage.setItem("flappy_marcio_perfil_retraido", "0");
    atualizarPerfilRecolhido();
    if (usuarioLogin) usuarioLogin.focus();
    return;
  }
  const iniciou = await iniciarPartidaServidor();
  if (!iniciou) return;
  reiniciar();
}

async function iniciarPartidaServidor() {
  tokenPartidaAtual = null;
  const dados = criarDadosApi("iniciar_partida");
  dados.append("dificuldade", dificuldade);
  dados.append("skin", skinSelecionada);

  try {
    const resposta = await fetch("sistema/requisicoes/jogo.php", {
      method: "POST",
      body: dados,
    });
    const retorno = await resposta.json();
    if (!retorno.ok || !retorno.partida || !retorno.partida.token) {
      throw new Error(retorno.mensagem || "Não consegui iniciar a partida.");
    }
    tokenPartidaAtual = retorno.partida.token;
    return true;
  } catch (erro) {
    mostrarMensagem(erro.message || "Não consegui iniciar a partida.");
    return false;
  }
}
