function prepararTela() {
  atualizarDificuldadeTela();
  atualizarSkins(null);
  atualizarPerfilRecolhido();
  atualizarPlacarTela();
  atualizarDicaFlutuante();

  carregarSessao();

  if (btnAlternarPerfil)
    btnAlternarPerfil.addEventListener("click", alternarPerfil);

  if (abasAcesso) {
    abasAcesso.querySelectorAll("button").forEach((botao) => {
      botao.addEventListener("click", () => {
        abasAcesso
          .querySelectorAll("button")
          .forEach((b) => b.classList.remove("ativo"));
        botao.classList.add("ativo");
        const cadastro = botao.dataset.aba === "cadastro";
        formLoginJogador.classList.toggle("escondido", cadastro);
        formCadastroJogador.classList.toggle("escondido", !cadastro);
        mostrarMensagem(
          cadastro
            ? "Crie um usuário e senha para salvar sua evolução."
            : "Entre para continuar seu progresso.",
          true,
        );
      });
    });
  }

  formLoginJogador.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    try {
      await enviarAcesso("login", usuarioLogin.value, senhaLogin.value);
      senhaLogin.value = "";
    } catch (erro) {
      mostrarMensagem(erro.message);
    }
  });

  formCadastroJogador.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    try {
      await enviarAcesso(
        "registrar",
        usuarioCadastro.value,
        senhaCadastro.value,
      );
      usuarioLogin.value = usuarioCadastro.value;
      usuarioCadastro.value = "";
      senhaCadastro.value = "";
      formCadastroJogador.classList.add("escondido");
      formLoginJogador.classList.remove("escondido");
      abasAcesso
        .querySelectorAll("button")
        .forEach((b) => b.classList.toggle("ativo", b.dataset.aba === "login"));
    } catch (erro) {
      mostrarMensagem(erro.message);
    }
  });

  if (btnSairJogador) {
    btnSairJogador.addEventListener("click", async () => {
      await fetch("sistema/requisicoes/jogo.php?acao=sair");
      definirJogador(null);
      mostrarMensagem("Você saiu da conta. Entre novamente para jogar.", true);
    });
  }

  document.querySelectorAll(".dificuldade-opcao").forEach((botao) => {
    botao.addEventListener("click", () => {
      dificuldade = botao.dataset.dificuldade || "normal";
      localStorage.setItem("flappy_marcio_dificuldade", dificuldade);
      atualizarDificuldadeTela();
      if (estado === "inicio") desenhar();
    });
  });

  document.querySelectorAll(".filtros-ranking button").forEach((botao) => {
    botao.addEventListener("click", () => {
      document
        .querySelectorAll(".filtros-ranking button")
        .forEach((b) => b.classList.remove("ativo"));
      botao.classList.add("ativo");
      filtroRanking = botao.dataset.rank || "geral";
      carregarRanking();
    });
  });

  document.querySelectorAll(".skin-opcao").forEach((botao) => {
    botao.addEventListener("click", () => {
      const escolhida = botao.dataset.skin || "classica";
      if (!skinLiberada(escolhida, perfilAtual)) {
        mostrarMensagem(
          "Essa skin ainda está bloqueada. Jogue mais para liberar.",
        );
        return;
      }
      skinSelecionada = escolhida;
      localStorage.setItem("flappy_marcio_skin", skinSelecionada);
      atualizarSkins(perfilAtual);
      if (estado === "inicio") desenhar();
    });
  });

  document.querySelectorAll(".menu-principal [data-ir]").forEach((botao) => {
    botao.addEventListener("click", () => {
      const alvo = botao.dataset.ir;
      const mapa = {
        jogo: painelJogo,
        ranking: document.querySelector(".ranking-card"),
        perfil: document.getElementById("areaPerfil"),
        manual: document.getElementById("manualCard"),
        conquistas: document.getElementById("areaConquistas"),
        creditos: document.getElementById("areaCreditos"),
      };
      if (alvo === "manual" && manualCard.classList.contains("fechado"))
        btnManual.click();
      (mapa[alvo] || painelJogo).scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    });
  });

  if (btnTelaLimpa) {
    btnTelaLimpa.addEventListener("click", () => {
      document.body.classList.toggle("modo-limpo");
      btnTelaLimpa.textContent = document.body.classList.contains(
        "modo-limpo",
      )
        ? "Sair da tela limpa"
        : "Tela limpa";
    });
  }

  btnTelaCheia.addEventListener("click", alternarTelaCheia);
  btnAtualizarRanking.addEventListener("click", carregarRanking);
  btnManual.addEventListener("click", () => {
    const fechado = manualCard.classList.toggle("fechado");
    manualIcone.textContent = fechado ? "+" : "−";
  });

  document.addEventListener("fullscreenchange", () => {
    if (
      !document.fullscreenElement &&
      document.body.classList.contains("jogo-expandido")
    ) {
      document.body.classList.remove("jogo-expandido");
      btnTelaCheia.classList.remove("btn-tela-ativa");
      btnTelaCheia.textContent = "⛶ Tela cheia";
    }
  });
}

function teclaEmCampo() {
  const tag = document.activeElement ? document.activeElement.tagName : "";
  return tag === "INPUT" || tag === "TEXTAREA";
}

document.addEventListener("keydown", (evento) => {
  if (evento.code === "Space") {
    if (teclaEmCampo()) return;
    evento.preventDefault();
    if (estado === "inicio" || estado === "fim") tentarComecar();
    else if (estado === "jogando") pular();
  }
  if (evento.code === "KeyP" && !teclaEmCampo()) {
    evento.preventDefault();
    alternarPausa();
  }
});

canvas.addEventListener("mousedown", pular);
canvas.addEventListener(
  "touchstart",
  (evento) => {
    evento.preventDefault();
    pular();
  },
  { passive: false },
);

prepararTela();
carregarRanking();
loop();
