async function salvarPontuacao() {
  if (salvouPontuacao || pontos <= 0 || !jogadorLogado) {
    if (pontos > 0 && !jogadorLogado)
      mostrarMensagem("Entre na conta para salvar essa pontuação.");
    atualizarResumoLocal();
    return;
  }

  salvouPontuacao = true;
  const duracao = (performance.now() - inicioPartida) / 1000;
  const dados = criarDadosApi("salvar");
  dados.append("pontos", pontos);
  dados.append("fase", faseDoJogo());
  dados.append("duracao", duracao.toFixed(2));
  dados.append("velocidade", multiplicadorVelocidade().toFixed(2));
  dados.append("dificuldade", dificuldade);
  dados.append("skin", skinSelecionada);
  dados.append("token_partida", tokenPartidaAtual || "");

  try {
    const resposta = await fetch("sistema/requisicoes/jogo.php", {
      method: "POST",
      body: dados,
    });
    const retorno = await resposta.json();
    if (!retorno.ok) throw new Error(retorno.mensagem || "Falha ao salvar");
    atualizarResumoJogador(
      retorno.recorde,
      retorno.posicao,
      retorno.conquistas || [],
      retorno.perfil,
    );
    const todas = await fetch("sistema/requisicoes/jogo.php?acao=jogador")
      .then((r) => r.json())
      .catch(() => null);
    if (todas && todas.ok) atualizarPainelConquistas(todas.conquistas || []);
    destacarConquistas(retorno.conquistas || []);
    const destaques = [];
    if (retorno.melhorou) destaques.push("Novo recorde pessoal");
    if (retorno.podio) destaques.push("Entrou no pódio");
    (retorno.conquistas || []).forEach((c) => destaques.push(c.titulo));
    (retorno.missoesConcluidas || []).forEach((m) =>
      destaques.push(`Missão: ${m.titulo}`),
    );
    mensagemFinal = destaques[0] || "Partida salva";
    tokenPartidaAtual = null;
    atualizarResumoLocal(retorno, duracao);
    atualizarEstatisticas(retorno.estatisticas);
    carregarRanking();
  } catch (erro) {
    mostrarMensagem("Não consegui salvar no ranking. O jogo segue, o banco que não colaborou.");
    tokenPartidaAtual = null;
    atualizarResumoLocal(null, duracao);
  }
}

function atualizarResumoLocal(retorno = null, duracao = null) {
  const tempo =
    duracao !== null
      ? duracao
      : inicioPartida
        ? (performance.now() - inicioPartida) / 1000
        : 0;
  const conquistas = retorno ? retorno.conquistas || [] : [];
  const missoes = retorno ? retorno.missoesConcluidas || [] : [];
  const blocos = [
    ["Pontuação", `${pontos} pontos`],
    ["Fase alcançada", `Fase ${faseDoJogo()}`],
    ["Tempo de jogo", `${tempo.toFixed(1)}s`],
    ["Velocidade final", `${multiplicadorVelocidade().toFixed(1)}x`],
    ["Dificuldade", modoAtual().nome],
    ["Skin usada", skinDados().nome],
  ];
  resumoFinal.innerHTML = blocos
    .map(
      (item) => `<div><strong>${item[0]}</strong><span>${item[1]}</span></div>`,
    )
    .join("");
  const extras = [];
  conquistas.forEach((c) => extras.push(c.titulo));
  missoes.forEach((m) => extras.push(`Missão: ${m.titulo}`));
  conquistasJogador.innerHTML = extras.length
    ? extras.map((t) => `<span>${escaparTexto(t)}</span>`).join("")
    : "<span>Continue jogando para liberar conquistas. Uma hora o Márcio engrena.</span>";
}

async function carregarRanking() {
  const textoOriginal = btnAtualizarRanking.textContent;
  btnAtualizarRanking.disabled = true;
  btnAtualizarRanking.textContent = "Atualizando...";
  try {
    let periodo = filtroRanking === "geral" ? "geral" : filtroRanking;
    let dificuldadeFiltro = "geral";
    if (String(filtroRanking).startsWith("dif:")) {
      dificuldadeFiltro = filtroRanking.split(":")[1] || "geral";
      periodo = "geral";
    }
    const resposta = await fetch(
      `sistema/requisicoes/jogo.php?acao=listar&periodo=${periodo}&dificuldade=${dificuldadeFiltro}`,
    );
    const retorno = await resposta.json();
    const lista = document.getElementById("ranking");
    lista.innerHTML = "";
    if (!retorno.ok) throw new Error(retorno.mensagem || "Falha");
    if (!retorno.ranking.length) {
      lista.innerHTML = '<li class="vazio">Nenhuma pontuação salva ainda. Seja o primeiro a passar vergonha no ranking.</li>';
      return;
    }
    retorno.ranking.forEach((item, indice) => {
      const li = document.createElement("li");
      li.className = indice < 3 ? `top${indice + 1}` : "";
      li.innerHTML = `<span class="posicao-ranking">${medalha(indice)}</span><span class="nome-ranking"><strong>${escaparTexto(item.nome)}</strong><small>${item.dificuldade} • Fase ${item.fase} • ${formatarData(item.data)}</small></span><span class="pontos-ranking">${item.pontos} pts</span>`;
      lista.appendChild(li);
    });
  } catch (erro) {
    document.getElementById("ranking").innerHTML =
      '<li class="vazio">Ative o MySQL e abra o instalar.php. Sem banco, nem o ranking acredita.</li>';
  } finally {
    btnAtualizarRanking.disabled = false;
    btnAtualizarRanking.textContent = textoOriginal;
  }
}

function preencherPerfil(perfil) {
  perfilAtual = perfil;
  perfilPartidas.textContent = perfil ? perfil.partidas : 0;
  perfilFase.textContent = perfil ? perfil.fase : 1;
  perfilMedia.textContent = perfil ? perfil.media : 0;
  perfilConquistas.textContent = perfil ? perfil.conquistas : 0;
  const nivel = perfil ? Number(perfil.nivel || 1) : 1;
  const atual = perfil ? Number(perfil.xpAtual || 0) : 0;
  const proximo = perfil ? Number(perfil.xpProximo || 100) : 100;
  if (nivelJogador) nivelJogador.textContent = `Nível ${nivel}`;
  if (tituloNivel)
    tituloNivel.textContent = perfil ? perfil.tituloNivel : "Iniciante";
  if (barraXp)
    barraXp.style.width = `${Math.min(100, (atual / proximo) * 100)}%`;
  if (xpTexto) xpTexto.textContent = `${atual} / ${proximo} XP`;
  atualizarSkins(perfil);
}

function atualizarResumoJogador(
  recorde,
  posicao,
  conquistas = null,
  perfil = null,
) {
  recordeJogador.textContent = Number(recorde || 0);
  posicaoJogador.textContent = posicao ? `${posicao}º` : "--";
  preencherPerfil(perfil);
  atualizarSkins(perfil);
  if (Array.isArray(conquistas) && conquistas.length) {
    conquistasJogador.innerHTML = conquistas
      .slice(0, 4)
      .map((item) => `<span>${escaparTexto(item.titulo)}</span>`)
      .join("");
    if (conquistas.some((item) => item.codigo))
      atualizarPainelConquistas(conquistas);
  }
}

async function carregarDadosJogador() {
  if (!jogadorLogado) {
    atualizarResumoJogador(0, null, [], null);
    return;
  }
  try {
    const resposta = await fetch("sistema/requisicoes/jogo.php?acao=jogador");
    const retorno = await resposta.json();
    if (retorno.ok && retorno.logado) definirJogador(retorno);
    else definirJogador(null);
  } catch (erro) {}
}

function atualizarEstatisticas(stats) {
  if (!stats) return;
  const campos = {
    statPartidas: stats.partidas,
    statJogadores: stats.jogadores,
    statMaior: stats.maior,
    statCampeao: stats.campeao,
  };
  Object.entries(campos).forEach(([id, valor]) => {
    const el = document.getElementById(id);
    if (el) el.textContent = valor;
  });
}

async function entrarTelaCheia() {
  document.body.classList.add("jogo-expandido");
  btnTelaCheia.classList.add("btn-tela-ativa");
  btnTelaCheia.textContent = "↙ Tela normal";
  if (!document.fullscreenElement && painelJogo.requestFullscreen) {
    try {
      await painelJogo.requestFullscreen();
    } catch (erro) {}
  }
}

async function sairTelaCheia() {
  document.body.classList.remove("jogo-expandido");
  btnTelaCheia.classList.remove("btn-tela-ativa");
  btnTelaCheia.textContent = "⛶ Tela cheia";
  if (document.fullscreenElement && document.exitFullscreen) {
    try {
      await document.exitFullscreen();
    } catch (erro) {}
  }
}

function alternarTelaCheia() {
  if (document.body.classList.contains("jogo-expandido")) sairTelaCheia();
  else entrarTelaCheia();
}

function atualizarDicaFlutuante() {
  if (!dicaFlutuante) return;
  if (estado === "jogando") {
    dicaFlutuante.classList.add("escondida");
    return;
  }
  dicaFlutuante.classList.remove("escondida");
  if (estado === "pausado")
    dicaFlutuante.innerHTML = "Pressione <strong>P</strong> para voltar ao caos";
  else if (estado === "fim")
    dicaFlutuante.innerHTML =
      "Pressione <strong>Espaço</strong> para tentar de novo";
  else
    dicaFlutuante.innerHTML = "Pressione <strong>Espaço</strong> para começar";
}
