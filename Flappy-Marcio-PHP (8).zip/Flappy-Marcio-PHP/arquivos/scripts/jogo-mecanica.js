function reiniciar() {
  estado = "jogando";
  pontos = 0;
  quadro = 0;
  chaoX = 0;
  inicioPartida = performance.now();
  canos = [];
  particulas = [];
  popups = [];
  powerups = [];
  brilhos = [];
  escudoAtivo = false;
  focoAtivo = 0;
  ultimoPowerup = 0;
  salvouPontuacao = false;
  mensagemFinal = "";
  avisoJogo = "Valendo!";
  faseAnterior = 1;
  shake = 0;
  passaro = criarPassaro();
  adicionarCano();
  atualizarPlacarTela();
  atualizarDicaFlutuante();
}

function adicionarCano() {
  const abertura = aberturaAtual();
  const minimo = 72;
  const maximo = altura - chaoAltura - abertura - 82;
  const topo = Math.floor(Math.random() * (maximo - minimo + 1)) + minimo;
  canos.push({
    x: largura + 40,
    topo,
    base: topo + abertura,
    passou: false,
    seed: Math.random() * 220,
    move: faseDoJogo() >= 4,
  });
}

function deslocamentoCano(cano) {
  if (!cano.move) return 0;
  return Math.sin((quadro + cano.seed) / 40) * amplitudeCano();
}

function pular() {
  if (estado !== "jogando") return;
  passaro.velocidade = Number(config.pulo || -8.25);
  passaro.frame = (passaro.frame + 1) % imagens.passaro.length;
  criarParticulas(10, "#fff6a7", passaro.x + 8, passaro.y + passaro.altura / 2);
  brilhos.push({ x: passaro.x + 12, y: passaro.y + 31, r: 6, vida: 34 });
}

function alternarPausa() {
  if (estado === "jogando") {
    estado = "pausado";
    avisoJogo = "Pausado";
  } else if (estado === "pausado") {
    estado = "jogando";
    avisoJogo = "Valendo!";
  }
  atualizarDicaFlutuante();
}

function encerrarJogo() {
  if (estado === "fim") return;
  estado = "fim";
  shake = 14;
  atualizarPlacarTela();
  atualizarDicaFlutuante();
  salvarPontuacao();
}

function criarParticulas(qtd, cor, x = passaro.x, y = passaro.y) {
  for (let i = 0; i < qtd; i++) {
    particulas.push({
      x,
      y: y + (Math.random() * 24 - 12),
      vx: -1.2 - Math.random() * 2.8,
      vy: Math.random() * 2.4 - 1.2,
      r: 2 + Math.random() * 3.3,
      vida: 28 + Math.random() * 22,
      cor,
    });
  }
}

function criarBrilho() {
  if (estado !== "jogando" || Math.random() > 0.025) return;
  brilhos.push({
    x: largura + 20,
    y: 50 + Math.random() * 490,
    r: 1.5 + Math.random() * 2.5,
    vida: 210,
  });
}

function criarPowerup() {
  if (estado !== "jogando") return;
  if (pontos < 3 || pontos - ultimoPowerup < 4) return;
  if (Math.random() > 0.28) return;
  const tipos = escudoAtivo ? ["foco"] : ["escudo", "foco"];
  const tipo = tipos[Math.floor(Math.random() * tipos.length)];
  ultimoPowerup = pontos;
  powerups.push({
    tipo,
    x: largura + 70,
    y: 120 + Math.random() * (altura - chaoAltura - 260),
    r: tipo === "escudo" ? 17 : 15,
    angulo: 0,
    pego: false,
  });
}

function aplicarPowerup(item) {
  item.pego = true;
  if (item.tipo === "escudo") {
    escudoAtivo = true;
    avisoJogo = "Escudo ativado!";
    popups.push({
      texto: "Escudo!",
      x: item.x,
      y: item.y - 18,
      vida: 70,
      cor: "#7dd3fc",
      tamanho: 24,
    });
    criarParticulas(24, "#7dd3fc", item.x, item.y);
    return;
  }
  focoAtivo = 260;
  avisoJogo = "Foco ativado!";
  popups.push({
    texto: "Foco!",
    x: item.x,
    y: item.y - 18,
    vida: 70,
    cor: "#c4b5fd",
    tamanho: 24,
  });
  criarParticulas(24, "#c4b5fd", item.x, item.y);
}

function atualizarPowerups(velocidade) {
  if (focoAtivo > 0 && estado === "jogando") focoAtivo--;
  criarPowerup();
  powerups.forEach((item) => {
    item.x -= velocidade * 0.95;
    item.angulo += 0.045;
    const dx = passaro.x + passaro.largura / 2 - item.x;
    const dy = passaro.y + passaro.altura / 2 - item.y;
    if (
      !item.pego &&
      estado === "jogando" &&
      Math.sqrt(dx * dx + dy * dy) < item.r + 28
    )
      aplicarPowerup(item);
  });
  powerups = powerups.filter((item) => !item.pego && item.x > -40);
}

function usarEscudo() {
  if (!escudoAtivo) return false;
  escudoAtivo = false;
  shake = 7;
  passaro.velocidade = Number(config.pulo || -8.25) * 0.72;
  canos = canos.filter(
    (cano) => cano.x + canoLargura < passaro.x - 18 || cano.x > passaro.x + 145,
  );
  avisoJogo = "Escudo salvou você!";
  popups.push({
    texto: "Defendeu!",
    x: passaro.x + 84,
    y: passaro.y,
    vida: 75,
    cor: "#7dd3fc",
    tamanho: 25,
  });
  criarParticulas(34, "#7dd3fc", passaro.x + 30, passaro.y + 28);
  return true;
}

function atualizarParticulas() {
  particulas.forEach((p) => {
    p.x += p.vx;
    p.y += p.vy;
    p.vida--;
  });
  particulas = particulas.filter((p) => p.vida > 0);
  popups.forEach((p) => {
    p.y -= 0.45;
    p.vida--;
  });
  popups = popups.filter((p) => p.vida > 0);
  criarBrilho();
  brilhos.forEach((e) => {
    e.x -= velocidadeAtual() * 0.28;
    e.vida--;
  });
  brilhos = brilhos.filter((e) => e.vida > 0 && e.x > -20);
}

function atualizar() {
  quadro++;
  const velocidade = velocidadeAtual();
  atualizarPowerups(velocidade);
  chaoX = (chaoX - velocidade) % 336;
  atualizarParticulas();
  if (shake > 0) shake--;
  if (estado !== "jogando") return;

  passaro.velocidade += Number(config.gravidade || 0.46);
  passaro.y += passaro.velocidade;
  passaro.angulo =
    passaro.velocidade < 0 ? -22 : Math.min(80, passaro.angulo + 3.2);
  passaro.frame = Math.floor(quadro / 7) % imagens.passaro.length;

  if (quadro % 4 === 0)
    criarParticulas(
      1,
      faseDoJogo() >= 4 ? "#b7f7ff" : "#ffffff",
      passaro.x + 6,
      passaro.y + 30,
    );
  if (quadro % intervaloCanos() === 0) adicionarCano();

  canos.forEach((cano) => {
    cano.x -= velocidade;
    if (!cano.passou && cano.x + canoLargura < passaro.x) {
      cano.passou = true;
      pontos++;
      avisoJogo = faseDoJogo() >= 4 ? "Canos em movimento!" : "Continue!";
      popups.push({
        texto: "+1",
        x: passaro.x + 84,
        y: passaro.y + 12,
        vida: 42,
        cor: "#ffe66d",
        tamanho: 22,
      });
      atualizarPlacarTela();
    }
  });
  canos = canos.filter((cano) => cano.x > -canoLargura - 10);

  if (passaro.y < -10 || passaro.y + passaro.altura > altura - chaoAltura) {
    if (!usarEscudo()) encerrarJogo();
    return;
  }
  for (const cano of canos) {
    if (colidiuComCano(cano)) {
      if (!usarEscudo()) encerrarJogo();
      return;
    }
  }
}

function colidiuComCano(cano) {
  const folga = 12;
  const px = passaro.x + folga;
  const py = passaro.y + folga;
  const pw = passaro.largura - folga * 2;
  const ph = passaro.altura - folga * 2;
  const ajuste = deslocamentoCano(cano);
  const topo = cano.topo + ajuste;
  const base = cano.base + ajuste;
  const dentroX = px < cano.x + canoLargura && px + pw > cano.x;
  return dentroX && (py < topo || py + ph > base);
}
