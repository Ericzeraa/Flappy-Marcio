function desenhar() {
  ctx.save();
  if (shake > 0)
    ctx.translate(
      Math.random() * shake - shake / 2,
      Math.random() * shake - shake / 2,
    );
  desenharFundo();
  desenharCenarioVivo();
  desenharVelocidade();
  desenharCanos();
  desenharPowerups();
  desenharParticulas();
  desenharPassaro();
  desenharEfeitosJogador();
  desenharChao();
  desenharHudCanvas();
  desenharPopups();
  if (estado === "inicio") desenharTelaInicial();
  if (estado === "pausado") desenharPausado();
  if (estado === "fim") desenharGameOver();
  ctx.restore();
}

function desenharFundo() {
  if (imagens.fundo.complete && imagens.fundo.naturalWidth > 0) {
    ctx.drawImage(imagens.fundo, 0, 0, largura, altura);
  } else {
    const gradiente = ctx.createLinearGradient(0, 0, 0, altura);
    gradiente.addColorStop(0, "#55c9d2");
    gradiente.addColorStop(0.64, "#62dbe0");
    gradiente.addColorStop(1, "#58df69");
    ctx.fillStyle = gradiente;
    ctx.fillRect(0, 0, largura, altura);
  }

  const luz = ctx.createLinearGradient(0, 0, largura, 0);
  luz.addColorStop(0, "rgba(255,255,255,.06)");
  luz.addColorStop(0.5, "rgba(255,255,255,0)");
  luz.addColorStop(1, "rgba(255,255,255,.08)");
  ctx.fillStyle = luz;
  ctx.fillRect(0, 0, largura, altura);
}

function desenharCenarioVivo() {
  ctx.save();
  brilhos.forEach((e) => {
    ctx.globalAlpha = Math.min(0.75, e.vida / 90);
    ctx.fillStyle = "#fff7b8";
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();
}

function desenharVelocidade() {
  if (estado !== "jogando" || faseDoJogo() < 3) return;
  ctx.save();
  ctx.strokeStyle = "rgba(255, 255, 255, .25)";
  ctx.lineWidth = 2;
  for (let i = 0; i < 9; i++) {
    const y = 60 + i * 74 + ((quadro * velocidadeAtual()) % 74);
    ctx.beginPath();
    ctx.moveTo(largura + 20, y);
    ctx.lineTo(largura - 90 - i * 12, y + 18);
    ctx.stroke();
  }
  ctx.restore();
}

function desenharCanos() {
  const solo = altura - chaoAltura + 18;
  canos.forEach((cano) => {
    const ajuste = deslocamentoCano(cano);
    const topo = Math.max(48, cano.topo + ajuste);
    const base = Math.min(altura - chaoAltura - 36, cano.base + ajuste);
    const alturaTopo = Math.max(140, topo + 24);
    const alturaBase = Math.max(260, solo - base + 70);
    ctx.save();
    ctx.translate(cano.x + canoLargura / 2, topo);
    ctx.scale(1, -1);
    ctx.drawImage(imagens.cano, -canoLargura / 2, 0, canoLargura, alturaTopo);
    ctx.restore();
    ctx.drawImage(imagens.cano, cano.x, base, canoLargura, alturaBase);
    ctx.save();
    const brilho = ctx.createLinearGradient(
      cano.x,
      base,
      cano.x + canoLargura,
      solo,
    );
    brilho.addColorStop(0, "rgba(255,255,255,.10)");
    brilho.addColorStop(0.5, "rgba(255,255,255,0)");
    brilho.addColorStop(1, "rgba(0,0,0,.14)");
    ctx.fillStyle = brilho;
    ctx.fillRect(
      cano.x + 5,
      base + 24,
      Math.max(8, canoLargura - 10),
      Math.max(0, solo - base),
    );
    ctx.restore();
  });
}

function desenharPowerups() {
  ctx.save();
  powerups.forEach((item) => {
    ctx.save();
    ctx.translate(item.x, item.y);
    ctx.rotate(item.angulo);
    if (item.tipo === "escudo") {
      const g = ctx.createRadialGradient(0, 0, 3, 0, 0, 25);
      g.addColorStop(0, "#ffffff");
      g.addColorStop(0.35, "#7dd3fc");
      g.addColorStop(1, "rgba(14,116,144,.18)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, 24, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,.95)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, -14);
      ctx.lineTo(13, -6);
      ctx.lineTo(9, 13);
      ctx.lineTo(0, 19);
      ctx.lineTo(-9, 13);
      ctx.lineTo(-13, -6);
      ctx.closePath();
      ctx.stroke();
    } else {
      ctx.strokeStyle = "#ddd6fe";
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(0, 0, 18, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,.9)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 9, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  });
  ctx.restore();
}

function desenharParticulas() {
  ctx.save();
  particulas.forEach((p) => {
    ctx.globalAlpha = Math.max(0, p.vida / 48);
    ctx.fillStyle = p.cor;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();
}

function desenharPassaro() {
  const img = imagens.passaro[passaro.frame];
  const centroX = passaro.x + passaro.largura / 2;
  const centroY = passaro.y + passaro.altura / 2 + Math.sin(quadro / 8) * 2.2;
  const pulso = 1 + Math.sin(quadro / 6) * 0.035;
  ctx.save();
  ctx.globalAlpha = 0.26;
  ctx.fillStyle = "#0f172a";
  ctx.beginPath();
  ctx.ellipse(centroX, centroY + 38, 28, 8, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.translate(centroX, centroY);
  ctx.rotate((passaro.angulo * Math.PI) / 180);
  ctx.scale(pulso, pulso);
  if (skinSelecionada === "dourada" || skinSelecionada === "neon") {
    ctx.globalAlpha = skinSelecionada === "neon" ? 0.44 : 0.28;
    ctx.fillStyle = skinSelecionada === "neon" ? "#f0abfc" : "#fde68a";
    ctx.beginPath();
    ctx.arc(0, 0, 42 + Math.sin(quadro / 7) * 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  ctx.filter = filtrosSkin[skinSelecionada] || "none";
  ctx.drawImage(
    img,
    -passaro.largura / 2,
    -passaro.altura / 2,
    passaro.largura,
    passaro.altura,
  );
  ctx.filter = "none";
  if (estado === "jogando") {
    ctx.globalAlpha = 0.28;
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(
      -24,
      4,
      12 + Math.sin(quadro / 3) * 4,
      Math.PI * 0.2,
      Math.PI * 1.65,
    );
    ctx.stroke();
  }
  ctx.restore();
}

function desenharEfeitosJogador() {
  if (!escudoAtivo) return;
  ctx.save();
  ctx.strokeStyle = "rgba(125,211,252,.92)";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(
    passaro.x + passaro.largura / 2,
    passaro.y + passaro.altura / 2,
    40 + Math.sin(quadro / 6) * 3,
    0,
    Math.PI * 2,
  );
  ctx.stroke();
  ctx.restore();
}

function desenharChao() {
  const y = altura - chaoAltura;
  for (let x = chaoX - 336; x < largura + 336; x += 336)
    ctx.drawImage(imagens.chao, x, y, 336, chaoAltura);
}

function textoComSombra(
  texto,
  x,
  y,
  tamanho = 28,
  alinhamento = "left",
  cor = "#fff",
) {
  ctx.save();
  ctx.font = `bold ${tamanho}px Arial`;
  ctx.textAlign = alinhamento;
  ctx.lineWidth = 5;
  ctx.strokeStyle = "rgba(0,0,0,.45)";
  ctx.fillStyle = cor;
  ctx.strokeText(texto, x, y);
  ctx.fillText(texto, x, y);
  ctx.restore();
}

function desenharBarraFase() {
  const x = 24,
    y = 86,
    w = 176,
    h = 12;
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,.25)";
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = "#ffe66d";
  ctx.fillRect(x, y, w * progressoFase(), h);
  ctx.strokeStyle = "rgba(255,255,255,.8)";
  ctx.strokeRect(x, y, w, h);
  ctx.font = "bold 13px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText(`Próxima fase: ${proximaFase()}`, x, y + 29);
  ctx.restore();
}

function desenharHudCanvas() {
  textoComSombra(`${pontos} pts`, largura - 24, 48, 36, "right");
  textoComSombra(`Fase ${faseDoJogo()}`, 24, 45, 24, "left");
  desenharBarraFase();
  const extras = [];
  if (escudoAtivo) extras.push("Escudo");
  if (focoAtivo > 0) extras.push("Foco");
  if (extras.length)
    textoComSombra(
      extras.join(" + "),
      largura - 24,
      90,
      18,
      "right",
      "#7dd3fc",
    );
  if (estado === "jogando" && avisoJogo)
    textoComSombra(avisoJogo, largura / 2, 132, 18, "center", "#ffe66d");
}

function desenharPopups() {
  ctx.save();
  popups.forEach((p) => {
    ctx.globalAlpha = Math.min(1, p.vida / 25);
    textoComSombra(p.texto, p.x, p.y, p.tamanho, "center", p.cor);
  });
  ctx.restore();
}

function caixaCentral(x, y, w, h, cor = "rgba(3,64,94,.75)") {
  x = Math.round(x);
  y = Math.round(y);
  const r = 24;
  ctx.save();
  ctx.fillStyle = cor;
  ctx.strokeStyle = "rgba(255,255,255,.66)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function caixaCentralizada(y, w, h, cor = "rgba(3,64,94,.75)") {
  caixaCentral((largura - w) / 2, y, w, h, cor);
}

function desenharTelaInicial() {
  ctx.save();
  ctx.drawImage(imagens.menu, 0, 0, largura, altura);
  ctx.fillStyle = "rgba(4,40,66,.48)";
  ctx.fillRect(0, 0, largura, altura);
  caixaCentralizada(210, 500, 314);
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.font = "bold 48px Arial";
  ctx.fillText("Flappy Márcio", largura / 2, 285);
  ctx.font = "22px Arial";
  ctx.fillText("Pressione espaço para voar", largura / 2, 338);
  ctx.font = "18px Arial";
  ctx.fillText(
    `${modoAtual().nome} • ${skinDados().nome} • missões`,
    largura / 2,
    380,
  );
  ctx.fillText("escudo, foco e fases progressivas", largura / 2, 410);
  ctx.font = "bold 20px Arial";
  ctx.fillStyle = "#ffe66d";
  ctx.fillText("Espaço inicia • P pausa", largura / 2, 464);
  ctx.restore();
}

function desenharPausado() {
  ctx.save();
  ctx.fillStyle = "rgba(4,40,66,.56)";
  ctx.fillRect(0, 0, largura, altura);
  caixaCentralizada(315, 430, 170);
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.font = "bold 42px Arial";
  ctx.fillText("Pausado", largura / 2, 386);
  ctx.font = "18px Arial";
  ctx.fillText("Pressione P para continuar", largura / 2, 430);
  ctx.restore();
}

function desenharGameOver() {
  const frame = imagens.marcio[Math.floor(quadro / 5) % imagens.marcio.length];
  ctx.save();
  ctx.fillStyle = "rgba(4,40,66,.72)";
  ctx.fillRect(0, 0, largura, altura);
  ctx.drawImage(frame, largura / 2 - 88, 116, 176, 176);
  caixaCentralizada(330, 500, 306);
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.font = "bold 40px Arial";
  ctx.fillText("Fim de jogo", largura / 2, 390);
  ctx.font = "21px Arial";
  ctx.fillText(`Pontuação: ${pontos}`, largura / 2, 438);
  ctx.fillText(`Fase: ${faseDoJogo()} • ${modoAtual().nome}`, largura / 2, 474);
  ctx.fillText(
    `Velocidade: ${multiplicadorVelocidade().toFixed(1)}x`,
    largura / 2,
    510,
  );
  if (mensagemFinal) {
    ctx.font = "bold 19px Arial";
    ctx.fillStyle = "#ffe66d";
    ctx.fillText(mensagemFinal, largura / 2, 552);
  }
  ctx.fillStyle = "#fff";
  ctx.font = "16px Arial";
  ctx.fillText("Pressione espaço para jogar novamente", largura / 2, 604);
  ctx.restore();
}

function loop() {
  atualizar();
  desenhar();
  requestAnimationFrame(loop);
}

function formatarData(dataTexto) {
  if (!dataTexto) return "Pontuação registrada";
  const data = new Date(dataTexto.replace(" ", "T"));
  if (Number.isNaN(data.getTime())) return "Pontuação registrada";
  return (
    data.toLocaleDateString("pt-BR") +
    " " +
    data.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
  );
}

function medalha(indice) {
  if (indice === 0) return "🥇";
  if (indice === 1) return "🥈";
  if (indice === 2) return "🥉";
  return indice + 1;
}

function escaparTexto(texto) {
  return String(texto).replace(
    /[&<>'"]/g,
    (c) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "'": "&#039;",
        '"': "&quot;",
      })[c],
  );
}
