const canvas = document.getElementById("jogo");
const ctx = canvas.getContext("2d");
const painelJogo = document.getElementById("painelJogo");
const areaPerfil = document.getElementById("areaPerfil");
const formLoginJogador = document.getElementById("formLoginJogador");
const formCadastroJogador = document.getElementById("formCadastroJogador");
const usuarioLogin = document.getElementById("usuarioLogin");
const senhaLogin = document.getElementById("senhaLogin");
const usuarioCadastro = document.getElementById("usuarioCadastro");
const senhaCadastro = document.getElementById("senhaCadastro");
const btnSairJogador = document.getElementById("btnSairJogador");
const btnAlternarPerfil = document.getElementById("btnAlternarPerfil");
const perfilMinimoNome = document.getElementById("perfilMinimoNome");
const abasAcesso = document.getElementById("abasAcesso");
const mensagemNome = document.getElementById("mensagemNome");
const nomeAtual = document.getElementById("nomeAtual");
const statusJogador = document.getElementById("statusJogador");
const recordeJogador = document.getElementById("recordeJogador");
const posicaoJogador = document.getElementById("posicaoJogador");
const faseAtual = document.getElementById("faseAtual");
const velocidadeHud = document.getElementById("velocidadeHud");
const hudDificuldade = document.getElementById("hudDificuldade");
const dificuldadeAtual = document.getElementById("dificuldadeAtual");
const perfilPartidas = document.getElementById("perfilPartidas");
const perfilFase = document.getElementById("perfilFase");
const perfilMedia = document.getElementById("perfilMedia");
const perfilConquistas = document.getElementById("perfilConquistas");
const btnTelaCheia = document.getElementById("btnTelaCheia");
const btnTelaLimpa = document.getElementById("btnTelaLimpa");
const skinAtual = document.getElementById("skinAtual");
const nivelJogador = document.getElementById("nivelJogador");
const tituloNivel = document.getElementById("tituloNivel");
const barraXp = document.getElementById("barraXp");
const xpTexto = document.getElementById("xpTexto");
const btnAtualizarRanking = document.getElementById("btnAtualizarRanking");
const btnManual = document.getElementById("btnManual");
const manualCard = document.getElementById("manualCard");
const manualIcone = document.getElementById("manualIcone");
const dicaFlutuante = document.querySelector(".dica-flutuante");
const conquistasJogador = document.getElementById("conquistasJogador");
const conquistasGrade = document.getElementById("conquistasGrade");
const statusConquistas = document.getElementById("statusConquistas");
const resumoFinal = document.getElementById("resumoFinal");

const config = Object.assign(
  {
    velocidade_inicial: 4.2,
    aumento_fase: 0.38,
    velocidade_maxima: 7.2,
    pontos_por_fase: 6,
    abertura_inicial: 210,
    abertura_minima: 168,
    gravidade: 0.46,
    pulo: -8.25,
  },
  window.CONFIG_JOGO || {},
);

const dificuldades = window.DIFICULDADES_JOGO || {
  facil: { nome: "Fácil", vel: 0.88, abertura: 28, max: -0.35 },
  normal: { nome: "Normal", vel: 1, abertura: 0, max: 0 },
  dificil: { nome: "Difícil", vel: 1.12, abertura: -18, max: 0.35 },
  insano: { nome: "Insano", vel: 1.23, abertura: -30, max: 0.65 },
};

const skins = window.SKINS_JOGO || {
  classica: { nome: "Clássica", pontos: 0, fase: 1, partidas: 0 },
  azul: { nome: "Azul", pontos: 8, fase: 1, partidas: 0 },
  dourada: { nome: "Dourada", pontos: 0, fase: 4, partidas: 0 },
  neon: { nome: "Neon", pontos: 0, fase: 1, partidas: 8 },
};

const conquistasCatalogo = window.CONQUISTAS_CATALOGO || [];
let conquistasLiberadas = new Set();

const filtrosSkin = {
  classica: "none",
  azul: "hue-rotate(155deg) saturate(1.25)",
  dourada: "sepia(0.65) saturate(1.7) hue-rotate(8deg) brightness(1.08)",
  neon: "hue-rotate(285deg) saturate(1.8) brightness(1.18)",
};

const imagens = {
  fundo: carregarImagem("arquivos/imagens/bg.png"),
  chao: carregarImagem("arquivos/imagens/base.png"),
  cano: carregarImagem("arquivos/imagens/pipe.png"),
  menu: carregarImagem("arquivos/imagens/menu.png"),
  passaro: [
    carregarImagem("arquivos/imagens/1.png"),
    carregarImagem("arquivos/imagens/2.png"),
    carregarImagem("arquivos/imagens/3.png"),
  ],
  marcio: Array.from({ length: 30 }, (_, i) =>
    carregarImagem(`animacao_marcio/frame-${String(i + 1).padStart(2, "0")}.gif`),
  ),
};

const largura = canvas.width;
const altura = canvas.height;
const chaoAltura = 90;
const canoLargura = 70;
let estado = "inicio";
let pontos = 0;
let quadro = 0;
let chaoX = 0;
let inicioPartida = 0;
let canos = [];
let particulas = [];
let popups = [];
let powerups = [];
let brilhos = [];
let escudoAtivo = false;
let focoAtivo = 0;
let ultimoPowerup = 0;
let salvouPontuacao = false;
let jogador = "";
let jogadorLogado = false;
let dificuldade = localStorage.getItem("flappy_marcio_dificuldade") || "normal";
let skinSelecionada = localStorage.getItem("flappy_marcio_skin") || "classica";
let perfilRecolhido = localStorage.getItem("flappy_marcio_perfil_retraido");
perfilRecolhido = perfilRecolhido === null ? true : perfilRecolhido === "1";
let perfilAtual = null;
let mensagemFinal = "";
let avisoJogo = "Pressione espaço para começar";
let faseAnterior = 1;
let shake = 0;
let filtroRanking = "geral";
let passaro = criarPassaro();
let tokenPartidaAtual = null;
function carregarImagem(caminho) {
  const img = new Image();
  img.src = caminho;
  return img;
}

function criarPassaro() {
  return {
    x: 105,
    y: 325,
    largura: 58,
    altura: 58,
    velocidade: 0,
    angulo: 0,
    frame: 0,
  };
}
