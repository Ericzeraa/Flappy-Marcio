<?php

return [
    'nome' => 'Flappy Márcio',
    'versao' => '2.0',
    'timezone' => 'America/Sao_Paulo',
    'admin_padrao' => [
        'usuario' => 'admin',
        'senha' => 'marcio@2026',
    ],
];
