<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar</title>
    <link rel="stylesheet" href="arquivos/estilos/estilo.css">
</head>
<body class="admin-body login-admin-body">
    <div class="fundo-decorativo"><span class="lua"></span><span class="planeta planeta-1"></span><span class="nuvem nuvem-1"></span><span class="brilho brilho-1"></span></div>
    <main class="login-admin-page">
        <form class="login-admin-card" method="post">
            <input type="hidden" name="acao" value="login_admin">
            <?= campo_csrf() ?>
            <span class="tag">Acesso restrito</span>
            <h1>Painel Flappy Márcio</h1>
            <p>Entre com o usuário do painel. Prometo que aqui não tem cano passando voando.</p>
            <?php if ($erro): ?><div class="alerta erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
            <label><span>Usuário</span><input type="text" name="usuario" placeholder="admin" autocomplete="username" required></label>
            <label><span>Senha</span><input type="password" name="senha" placeholder="Senha" autocomplete="current-password" required></label>
            <button class="btn-link cheio" type="submit">Entrar</button>
            <a class="link-voltar" href="index.php">Voltar ao jogo</a>
        </form>
    </main>
</body>
</html>
