            <div class="admin-card">
                <span class="subtitulo">Resumo do backend</span><h2>Indicadores do jogo</h2>
                <div class="lista-admin">
                    <div><strong>Ranking ativo</strong><span><?= (int) ($indicadoresTecnicos['totalRanking'] ?? 0) ?> jogadores no ranking</span></div>
                    <div><strong>Histórico recente</strong><span><?= (int) ($indicadoresTecnicos['ultimasPartidas'] ?? 0) ?> partidas recentes</span></div>
                    <div><strong>Modos utilizados</strong><span><?= (int) ($indicadoresTecnicos['modosUsados'] ?? 0) ?> modos já testados</span></div>
                    <div><strong>Tempo médio</strong><span><?= number_format((float) ($indicadoresTecnicos['mediaTempo'] ?? 0), 1, ',', '.') ?>s por partida</span></div>
                    <div><strong>Missões de hoje</strong><span><?= (int) ($indicadoresTecnicos['aproveitamentoMissoesHoje'] ?? 0) ?> missões concluídas</span></div>
                </div>
            </div>
