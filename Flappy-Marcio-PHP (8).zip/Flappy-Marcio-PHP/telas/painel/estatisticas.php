        <section class="admin-stats">
            <article><span>Partidas</span><strong><?= (int) $stats['partidas'] ?></strong></article>
            <article><span>Hoje</span><strong><?= (int) ($stats['partidas_hoje'] ?? 0) ?></strong></article>
            <article><span>Jogadores</span><strong><?= (int) $stats['jogadores'] ?></strong></article>
            <article><span>Ativos na semana</span><strong><?= (int) ($stats['jogadores_ativos'] ?? 0) ?></strong></article>
            <article><span>Maior ponto</span><strong><?= (int) $stats['maior'] ?></strong></article>
            <article><span>Maior hoje</span><strong><?= (int) ($stats['maior_hoje'] ?? 0) ?></strong></article>
            <article><span>Média</span><strong><?= number_format((float) $stats['media'], 1, ',', '.') ?></strong></article>
            <article><span>Tempo médio</span><strong><?= number_format((float) ($stats['tempo_medio'] ?? 0), 1, ',', '.') ?>s</strong></article>
            <article><span>Fase máxima</span><strong><?= (int) $stats['fase'] ?></strong></article>
            <article><span>Modo mais jogado</span><strong><?= htmlspecialchars($stats['dificuldade']) ?></strong></article>
            <article><span>Melhor jogador</span><strong><?= htmlspecialchars($stats['campeao'] ?? 'Aguardando') ?></strong></article>
            <article><span>Mais ativo</span><strong><?= htmlspecialchars($stats['mais_ativo'] ?? 'Aguardando') ?></strong></article>
        </section>
        <section class="admin-grid">
