        <header class="admin-hero">
            <div>
                <span class="tag">Painel do jogo</span>
                <h1>Painel do jogo</h1>
                <p>Aqui dá para ver o ranking, conferir as últimas partidas e ajustar a dificuldade sem ficar caçando arquivo no projeto.</p>
            </div>
            <div class="acoes-admin-topo"><a class="btn-link" href="index.php">Voltar ao jogo</a><a class="btn-link" href="painel.php?exportar=ranking">CSV ranking</a><a class="btn-link" href="painel.php?exportar=partidas">CSV partidas</a><a class="btn-link claro" href="painel.php?sair=1">Sair</a></div>
        </header>
