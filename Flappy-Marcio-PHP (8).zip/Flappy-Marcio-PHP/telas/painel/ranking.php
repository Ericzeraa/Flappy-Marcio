            <div class="admin-card grande">
                <div class="titulo-card"><div><span class="subtitulo">Banco de dados</span><h2>Ranking completo</h2></div></div>
                <div class="tabela-wrap">
                    <table>
                        <thead><tr><th>#</th><th>Jogador</th><th>Modo</th><th>Pontos</th><th>Fase</th><th>Tempo</th><th>Vel.</th><th>Data</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($ranking as $i => $item): ?>
                            <tr>
                                <td><?= $i + 1 ?></td><td><?= htmlspecialchars($item['nome']) ?></td><td><?= htmlspecialchars($item['dificuldade']) ?></td><td><?= (int) $item['pontos'] ?></td><td><?= (int) $item['fase'] ?></td><td><?= number_format((float) $item['duracao_seg'], 1, ',', '.') ?>s</td><td><?= number_format((float) $item['velocidade_final'], 1, ',', '.') ?>x</td><td><?= data_br($item['atualizado_em']) ?></td>
                                <td><form method="post" onsubmit="return confirm('Remover este jogador?')"><input type="hidden" name="acao" value="excluir_jogador"><?= campo_csrf() ?><input type="hidden" name="jogador_id" value="<?= (int) $item['id'] ?>"><button class="btn-mini" type="submit">Excluir</button></form></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$ranking): ?><tr><td colspan="9">Nenhuma pontuação salva ainda. O ranking está em paz por enquanto.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
