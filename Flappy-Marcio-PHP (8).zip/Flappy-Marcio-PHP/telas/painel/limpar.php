        </section>
        <form class="limpar-card" method="post" onsubmit="return confirm('Limpar ranking, histórico, conquistas e missões?')"><input type="hidden" name="acao" value="limpar_ranking"><?= campo_csrf() ?><button type="submit">Limpar ranking e histórico</button></form>
