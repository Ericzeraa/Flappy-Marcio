            <div class="admin-card">
                <span class="subtitulo">Missões</span><h2>Missões concluídas</h2>
                <div class="lista-admin">
                    <?php foreach ($missoes as $m): ?><div><strong><?= htmlspecialchars($m['titulo']) ?></strong><span><?= htmlspecialchars($m['nome']) ?> • <?= data_br($m['criado_em']) ?></span></div><?php endforeach; ?>
                    <?php if (!$missoes): ?><p>Nenhuma missão concluída ainda. Está todo mundo aquecendo.</p><?php endif; ?>
                </div>
            </div>
