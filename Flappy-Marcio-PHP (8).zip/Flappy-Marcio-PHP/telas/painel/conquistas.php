            <div class="admin-card">
                <span class="subtitulo">Conquistas</span><h2>Últimas conquistas</h2>
                <div class="lista-admin">
                    <?php foreach ($conquistas as $c): ?><div><strong><?= htmlspecialchars($c['titulo']) ?></strong><span><?= htmlspecialchars($c['nome']) ?> • <?= htmlspecialchars($c['descricao']) ?></span></div><?php endforeach; ?>
                    <?php if (!$conquistas): ?><p>Nenhuma conquista liberada ainda. O Márcio está economizando medalha.</p><?php endif; ?>
                </div>
            </div>
