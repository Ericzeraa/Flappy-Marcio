<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel - Flappy Márcio</title>
    <link rel="stylesheet" href="arquivos/estilos/estilo.css">
</head>
<body class="admin-body">
    <div class="fundo-decorativo"><span class="lua"></span><span class="planeta planeta-1"></span><span class="nuvem nuvem-1"></span><span class="brilho brilho-1"></span></div>
    <main class="admin-page">
