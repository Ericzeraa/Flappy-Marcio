            <form class="admin-card" method="post">
                <input type="hidden" name="acao" value="salvar_config">
                <?= campo_csrf() ?>
                <span class="subtitulo">Ajustes</span><h2>Configurações do jogo</h2>
                <div class="config-grid">
                    <?php foreach ($configs as $chave => $valor): ?>
                        <label><span><?= ucwords(str_replace('_', ' ', $chave)) ?></span><input type="number" step="0.01" name="<?= htmlspecialchars($chave) ?>" value="<?= htmlspecialchars((string) $valor) ?>"></label>
                    <?php endforeach; ?>
                </div>
                <button class="btn-link cheio" type="submit">Salvar ajustes</button>
            </form>
