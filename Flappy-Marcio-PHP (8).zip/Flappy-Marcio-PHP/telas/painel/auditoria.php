            <div class="admin-card">
                <span class="subtitulo">Auditoria</span><h2>Últimos eventos</h2>
                <div class="lista-admin">
                    <?php foreach ($auditoria as $evento): ?>
                        <?php $detalhes = json_decode((string) ($evento['dados_json'] ?? ''), true) ?: []; ?>
                        <div><strong><?= htmlspecialchars(str_replace('_', ' ', $evento['evento'])) ?></strong><span><?= data_br($evento['criado_em']) ?><?= !empty($detalhes) ? ' • ' . htmlspecialchars(json_encode($detalhes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) : '' ?></span></div>
                    <?php endforeach; ?>
                    <?php if (!$auditoria): ?><p>Nenhum evento registrado ainda.</p><?php endif; ?>
                </div>
            </div>
