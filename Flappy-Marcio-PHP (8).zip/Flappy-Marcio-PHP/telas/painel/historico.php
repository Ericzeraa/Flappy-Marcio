            <div class="admin-card">
                <span class="subtitulo">Histórico</span><h2>Últimas partidas</h2>
                <div class="lista-admin">
                    <?php foreach ($partidas as $p): ?><div><strong><?= htmlspecialchars($p['nome']) ?></strong><span><?= htmlspecialchars($p['dificuldade']) ?> • <?= (int) $p['pontos'] ?> pts • fase <?= (int) $p['fase'] ?> • <?= data_br($p['criado_em']) ?></span></div><?php endforeach; ?>
                    <?php if (!$partidas): ?><p>Nenhuma partida jogada ainda.</p><?php endif; ?>
                </div>
            </div>
