            <div class="admin-card">
                <span class="subtitulo">Modos</span><h2>Desempenho por dificuldade</h2>
                <div class="lista-admin">
                    <?php foreach ($porDificuldade as $d): ?><div><strong><?= htmlspecialchars($d['dificuldade']) ?></strong><span><?= (int) $d['partidas'] ?> partidas • maior <?= (int) $d['maior'] ?> pts • média <?= number_format((float) $d['media'], 1, ',', '.') ?></span></div><?php endforeach; ?>
                    <?php if (!$porDificuldade): ?><p>Nenhuma partida jogada ainda.</p><?php endif; ?>
                </div>
            </div>
