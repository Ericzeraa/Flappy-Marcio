<?php

spl_autoload_register(function (string $classe): void {
    $prefixo = 'Sistema\\';
    if (strncmp($classe, $prefixo, strlen($prefixo)) !== 0) {
        return;
    }

    $relativo = substr($classe, strlen($prefixo));
    $arquivo = __DIR__ . '/../' . str_replace('\\', '/', $relativo) . '.php';

    if (is_file($arquivo)) {
        require_once $arquivo;
    }
});
