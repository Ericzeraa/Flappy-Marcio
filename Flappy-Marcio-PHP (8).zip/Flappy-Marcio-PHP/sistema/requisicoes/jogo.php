<?php
require_once __DIR__ . '/../funcoes_gerais.php';
\Sistema\Base\Sessao::start();
\Sistema\Base\CabecalhoSeguro::segurancaBasica();

try {
    $controller = new \Sistema\Controle\ControleJogo();
    $controller->executar();
} catch (Throwable $e) {
    resposta_json(['ok' => false, 'mensagem' => $e->getMessage()], 500);
}
