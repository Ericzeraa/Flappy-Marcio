<?php

namespace Sistema\Repositorios;

use PDO;

class RepositorioConfiguracao
{
    private const PADRAO = [
        'velocidade_inicial' => 4.20,
        'aumento_fase' => 0.38,
        'velocidade_maxima' => 7.20,
        'pontos_por_fase' => 6,
        'abertura_inicial' => 210,
        'abertura_minima' => 168,
        'gravidade' => 0.46,
        'pulo' => -8.25,
    ];

    public function __construct(private PDO $pdo) {}

    public function listar(): array
    {
        $config = self::PADRAO;
        foreach ($this->pdo->query('SELECT chave, valor FROM configuracoes')->fetchAll() as $linha) {
            if (array_key_exists($linha['chave'], $config)) {
                $config[$linha['chave']] = is_numeric($linha['valor']) ? (float) $linha['valor'] : $linha['valor'];
            }
        }
        return $config;
    }

    public function salvar(string $chave, float $valor): void
    {
        if (!array_key_exists($chave, self::PADRAO)) {
            return;
        }
        $stmt = $this->pdo->prepare('UPDATE configuracoes SET valor = ? WHERE chave = ?');
        $stmt->execute([(string) $valor, $chave]);
    }

    public function chavesPermitidas(): array
    {
        return array_keys(self::PADRAO);
    }
}
