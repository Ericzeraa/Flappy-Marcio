<?php

namespace Sistema\Repositorios;

use PDO;

class RepositorioAdministrativo
{
    public function __construct(private PDO $pdo) {}

    public function senhaHash(string $usuario): ?string
    {
        $stmt = $this->pdo->prepare('SELECT senha_hash FROM administradores WHERE usuario = ? LIMIT 1');
        $stmt->execute([$usuario]);
        $admin = $stmt->fetch();
        return $admin['senha_hash'] ?? null;
    }

    public function limparDadosDoJogo(): void
    {
        $this->pdo->exec('DELETE FROM missoes_concluidas');
        $this->pdo->exec('DELETE FROM conquistas');
        $this->pdo->exec('DELETE FROM pontuacoes');
        $this->pdo->exec('DELETE FROM partidas');
        $this->pdo->exec('DELETE FROM jogadores');
    }

    public function rankingCompleto(int $limite = 30): array
    {
        return $this->pdo->query('SELECT j.id, j.nome, p.dificuldade, p.pontos, p.fase, p.duracao_seg, p.velocidade_final, p.atualizado_em
            FROM pontuacoes p
            JOIN jogadores j ON j.id = p.jogador_id
            ORDER BY p.pontos DESC, p.atualizado_em ASC
            LIMIT ' . max(1, min(100, $limite)))->fetchAll();
    }

    public function ultimasPartidas(int $limite = 20): array
    {
        return $this->pdo->query('SELECT j.nome, p.dificuldade, p.pontos, p.fase, p.duracao_seg, p.velocidade_final, p.criado_em
            FROM partidas p
            JOIN jogadores j ON j.id = p.jogador_id
            ORDER BY p.criado_em DESC
            LIMIT ' . max(1, min(100, $limite)))->fetchAll();
    }

    public function ultimasConquistas(int $limite = 20): array
    {
        return $this->pdo->query('SELECT j.nome, c.titulo, c.descricao, c.criado_em
            FROM conquistas c
            JOIN jogadores j ON j.id = c.jogador_id
            ORDER BY c.criado_em DESC
            LIMIT ' . max(1, min(100, $limite)))->fetchAll();
    }

    public function ultimasMissoes(int $limite = 20): array
    {
        return $this->pdo->query('SELECT j.nome, m.titulo, m.data_ref, m.criado_em
            FROM missoes_concluidas m
            JOIN jogadores j ON j.id = m.jogador_id
            ORDER BY m.criado_em DESC
            LIMIT ' . max(1, min(100, $limite)))->fetchAll();
    }

    public function desempenhoPorDificuldade(): array
    {
        return $this->pdo->query('SELECT dificuldade, COUNT(*) partidas, COALESCE(MAX(pontos),0) maior, COALESCE(AVG(pontos),0) media FROM partidas GROUP BY dificuldade ORDER BY partidas DESC')->fetchAll();
    }
    public function auditoriaRecente(int $limite = 20): array
    {
        $limite = max(1, min(100, $limite));
        return $this->pdo->query('SELECT evento, jogador_id, dados_json, ip, criado_em FROM auditoria_eventos ORDER BY criado_em DESC LIMIT ' . $limite)->fetchAll();
    }

}
