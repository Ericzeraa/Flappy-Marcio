<?php

namespace Sistema\Repositorios;

use PDO;

class TentativasLogin
{
    public function __construct(private PDO $pdo) {}

    public function registrar(string $chave, string $contexto, string $ip): void
    {
        $this->limparAntigas();
        $stmt = $this->pdo->prepare('INSERT INTO tentativas_acesso (chave_hash, contexto, ip, criado_em) VALUES (?, ?, ?, NOW())');
        $stmt->execute([sha1($chave), substr($contexto, 0, 50), substr($ip, 0, 45)]);
    }

    public function contar(string $chave, int $janelaMinutos): int
    {
        $janelaMinutos = max(1, min(1440, $janelaMinutos));
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM tentativas_acesso WHERE chave_hash = ? AND criado_em >= DATE_SUB(NOW(), INTERVAL ' . $janelaMinutos . ' MINUTE)');
        $stmt->execute([sha1($chave)]);
        return (int) $stmt->fetchColumn();
    }

    public function limparAntigas(): void
    {
        $this->pdo->exec('DELETE FROM tentativas_acesso WHERE criado_em < DATE_SUB(NOW(), INTERVAL 1 DAY)');
    }
}
