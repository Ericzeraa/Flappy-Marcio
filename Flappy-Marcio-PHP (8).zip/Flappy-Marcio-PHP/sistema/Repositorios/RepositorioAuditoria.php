<?php

namespace Sistema\Repositorios;

use PDO;
use Throwable;

class RepositorioAuditoria
{
    public function __construct(private PDO $pdo) {}

    public function registrar(string $evento, ?int $jogadorId = null, array $dados = [], ?string $ip = null, ?string $agente = null): void
    {
        try {
            $stmt = $this->pdo->prepare('INSERT INTO auditoria_eventos (evento, jogador_id, dados_json, ip, agente) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([
                $evento,
                $jogadorId,
                json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $ip,
                $agente,
            ]);
        } catch (Throwable) {}
    }

    public function recentes(int $limite = 20): array
    {
        $limite = max(1, min(100, $limite));
        return $this->pdo->query('SELECT evento, jogador_id, dados_json, ip, criado_em FROM auditoria_eventos ORDER BY criado_em DESC LIMIT ' . $limite)->fetchAll();
    }
}
