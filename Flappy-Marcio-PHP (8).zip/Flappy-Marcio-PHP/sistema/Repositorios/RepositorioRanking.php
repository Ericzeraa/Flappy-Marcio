<?php

namespace Sistema\Repositorios;

use PDO;

class RepositorioRanking
{
    public function __construct(private PDO $pdo) {}

    public function transacao(callable $rotina): mixed
    {
        $this->pdo->beginTransaction();
        try {
            $resultado = $rotina();
            $this->pdo->commit();
            return $resultado;
        } catch (\Throwable $erro) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $erro;
        }
    }

    public function listar(string $dificuldade = 'geral', string $periodo = 'geral', int $limite = 10): array
    {
        $where = [];
        $params = [];

        if ($dificuldade !== 'geral') {
            $where[] = 'p.dificuldade = ?';
            $params[] = $dificuldade;
        }
        if ($periodo === 'hoje') {
            $where[] = 'DATE(p.atualizado_em) = CURDATE()';
        } elseif ($periodo === 'semana') {
            $where[] = 'p.atualizado_em >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        }

        $sqlWhere = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $stmt = $this->pdo->prepare("SELECT j.nome, p.pontos, p.fase, p.duracao_seg, p.velocidade_final, p.dificuldade, p.atualizado_em data
            FROM pontuacoes p
            JOIN jogadores j ON j.id = p.jogador_id
            {$sqlWhere}
            ORDER BY p.pontos DESC, p.atualizado_em ASC
            LIMIT " . max(1, min(50, $limite)));
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function registrarPartida(int $jogadorId, int $pontos, int $fase, float $duracao, float $velocidade, string $dificuldade, string $skin): void
    {
        $stmt = $this->pdo->prepare('INSERT INTO partidas (jogador_id, pontos, fase, duracao_seg, velocidade_final, dificuldade, skin) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$jogadorId, $pontos, $fase, $duracao, $velocidade, $dificuldade, $skin]);
    }

    public function recordeDaDificuldade(int $jogadorId, string $dificuldade): ?array
    {
        $stmt = $this->pdo->prepare('SELECT pontos FROM pontuacoes WHERE jogador_id = ? AND dificuldade = ? LIMIT 1');
        $stmt->execute([$jogadorId, $dificuldade]);
        return $stmt->fetch() ?: null;
    }

    public function salvarRecorde(int $jogadorId, string $dificuldade, int $pontos, int $fase, float $duracao, float $velocidade): void
    {
        $stmt = $this->pdo->prepare('INSERT INTO pontuacoes (jogador_id, dificuldade, pontos, fase, duracao_seg, velocidade_final, atualizado_em)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE pontos = VALUES(pontos), fase = VALUES(fase), duracao_seg = VALUES(duracao_seg), velocidade_final = VALUES(velocidade_final), atualizado_em = NOW()');
        $stmt->execute([$jogadorId, $dificuldade, $pontos, $fase, $duracao, $velocidade]);
    }

    public function melhorRecorde(int $jogadorId): array
    {
        $stmt = $this->pdo->prepare('SELECT pontos, fase FROM pontuacoes WHERE jogador_id = ? ORDER BY pontos DESC LIMIT 1');
        $stmt->execute([$jogadorId]);
        return $stmt->fetch() ?: ['pontos' => 0, 'fase' => 1];
    }

    public function posicao(int $jogadorId, string $dificuldade = 'geral'): ?int
    {
        if ($dificuldade !== 'geral') {
            $stmt = $this->pdo->prepare('SELECT jogador_id FROM pontuacoes WHERE dificuldade = ? ORDER BY pontos DESC, atualizado_em ASC');
            $stmt->execute([$dificuldade]);
        } else {
            $stmt = $this->pdo->query('SELECT jogador_id FROM pontuacoes ORDER BY pontos DESC, atualizado_em ASC');
        }

        $posicao = 1;
        while ($linha = $stmt->fetch()) {
            if ((int) $linha['jogador_id'] === $jogadorId) {
                return $posicao;
            }
            $posicao++;
        }
        return null;
    }

    public function conquistasDoJogador(int $jogadorId): array
    {
        $stmt = $this->pdo->prepare('SELECT codigo, titulo, descricao, criado_em FROM conquistas WHERE jogador_id = ? ORDER BY criado_em DESC');
        $stmt->execute([$jogadorId]);
        return $stmt->fetchAll();
    }

    public function inserirConquista(int $jogadorId, string $codigo, string $titulo, string $descricao): bool
    {
        $stmt = $this->pdo->prepare('INSERT IGNORE INTO conquistas (jogador_id, codigo, titulo, descricao) VALUES (?, ?, ?, ?)');
        $stmt->execute([$jogadorId, $codigo, $titulo, $descricao]);
        return $stmt->rowCount() > 0;
    }

    public function inserirMissao(int $jogadorId, string $codigo, string $titulo, string $data): bool
    {
        $stmt = $this->pdo->prepare('INSERT IGNORE INTO missoes_concluidas (jogador_id, codigo, titulo, data_ref) VALUES (?, ?, ?, ?)');
        $stmt->execute([$jogadorId, $codigo, $titulo, $data]);
        return $stmt->rowCount() > 0;
    }

    public function perfilBruto(int $jogadorId): array
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) partidas, COALESCE(MAX(pontos),0) melhor, COALESCE(MAX(fase),1) fase, COALESCE(AVG(pontos),0) media, COALESCE(SUM(duracao_seg),0) tempo, COALESCE(SUM(pontos),0) pontos_total FROM partidas WHERE jogador_id = ?');
        $stmt->execute([$jogadorId]);
        return $stmt->fetch() ?: [];
    }

    public function totalConquistas(int $jogadorId): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM conquistas WHERE jogador_id = ?');
        $stmt->execute([$jogadorId]);
        return (int) $stmt->fetchColumn();
    }

    public function missoesHoje(int $jogadorId): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM missoes_concluidas WHERE jogador_id = ? AND data_ref = CURDATE()');
        $stmt->execute([$jogadorId]);
        return (int) $stmt->fetchColumn();
    }
}
