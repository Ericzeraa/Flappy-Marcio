<?php

namespace Sistema\Repositorios;

use PDO;

class RepositorioJogador
{
    public function __construct(private PDO $pdo) {}

    public function existeUsuario(string $usuario): bool
    {
        $stmt = $this->pdo->prepare('SELECT id FROM jogadores WHERE nome_chave = ? LIMIT 1');
        $stmt->execute([$usuario]);
        return (bool) $stmt->fetch();
    }

    public function criar(string $usuario, string $senhaHash): array
    {
        $stmt = $this->pdo->prepare('INSERT INTO jogadores (nome, nome_chave, senha_hash) VALUES (?, ?, ?)');
        $stmt->execute([$usuario, $usuario, $senhaHash]);
        return $this->buscarPorId((int) $this->pdo->lastInsertId());
    }

    public function buscarPorUsuario(string $usuario): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM jogadores WHERE nome_chave = ? LIMIT 1');
        $stmt->execute([$usuario]);
        return $stmt->fetch() ?: null;
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM jogadores WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function atualizarSkin(int $id, string $skin): void
    {
        $stmt = $this->pdo->prepare('UPDATE jogadores SET skin = ? WHERE id = ?');
        $stmt->execute([$skin, $id]);
    }

    public function excluir(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM jogadores WHERE id = ?');
        $stmt->execute([$id]);
    }
}
