<?php

namespace Sistema\Repositorios;

use PDO;

class RepositorioTokenPartida
{
    public function __construct(private PDO $pdo) {}

    public function criar(int $jogadorId, string $token, string $dificuldade, string $skin): void
    {
        $this->removerExpirados();
        $stmt = $this->pdo->prepare('INSERT INTO partidas_tokens (jogador_id, token, dificuldade, skin, criado_em) VALUES (?, ?, ?, ?, NOW())');
        $stmt->execute([$jogadorId, $token, $dificuldade, $skin]);
    }

    public function buscarValido(int $jogadorId, string $token): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM partidas_tokens WHERE jogador_id = ? AND token = ? AND usado_em IS NULL AND criado_em >= DATE_SUB(NOW(), INTERVAL 30 MINUTE) LIMIT 1');
        $stmt->execute([$jogadorId, $token]);
        return $stmt->fetch() ?: null;
    }

    public function marcarUsado(int $id): void
    {
        $stmt = $this->pdo->prepare('UPDATE partidas_tokens SET usado_em = NOW() WHERE id = ? AND usado_em IS NULL');
        $stmt->execute([$id]);
    }

    public function removerExpirados(): void
    {
        $this->pdo->exec('DELETE FROM partidas_tokens WHERE criado_em < DATE_SUB(NOW(), INTERVAL 2 HOUR) OR usado_em < DATE_SUB(NOW(), INTERVAL 2 HOUR)');
    }
}
