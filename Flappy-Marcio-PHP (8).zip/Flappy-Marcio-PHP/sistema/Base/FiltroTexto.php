<?php

namespace Sistema\Base;

class FiltroTexto
{
    public static function texto(?string $valor): string
    {
        $valor = trim((string) $valor);
        return preg_replace('/\s+/', ' ', $valor) ?? '';
    }

    public static function usuario(string $usuario): string
    {
        $usuario = mb_strtolower(self::texto($usuario), 'UTF-8');
        return preg_replace('/[^a-z0-9_.-]/', '', $usuario) ?? '';
    }

    public static function html(mixed $valor): string
    {
        return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
    }
}
