<?php

namespace Sistema\Base;

class Requisicao
{
    public function __construct(private array $get, private array $post, private array $server) {}

    public static function capturar(): self
    {
        return new self($_GET, $_POST, $_SERVER);
    }

    public function metodo(): string
    {
        return strtoupper((string) ($this->server['REQUEST_METHOD'] ?? 'GET'));
    }

    public function acao(): string
    {
        return $this->string('acao', 'listar');
    }

    public function string(string $campo, string $padrao = ''): string
    {
        $valor = $this->post[$campo] ?? $this->get[$campo] ?? $padrao;
        return FiltroTexto::texto(is_scalar($valor) ? (string) $valor : $padrao);
    }

    public function postTexto(string $campo, string $padrao = ''): string
    {
        $valor = $this->post[$campo] ?? $padrao;
        return FiltroTexto::texto(is_scalar($valor) ? (string) $valor : $padrao);
    }

    public function getTexto(string $campo, string $padrao = ''): string
    {
        $valor = $this->get[$campo] ?? $padrao;
        return FiltroTexto::texto(is_scalar($valor) ? (string) $valor : $padrao);
    }

    public function postInt(string $campo): ?int
    {
        $valor = filter_var($this->post[$campo] ?? null, FILTER_VALIDATE_INT);
        return $valor === false ? null : $valor;
    }

    public function postFloat(string $campo): ?float
    {
        $valor = str_replace(',', '.', (string) ($this->post[$campo] ?? ''));
        $validado = filter_var($valor, FILTER_VALIDATE_FLOAT);
        return $validado === false ? null : (float) $validado;
    }

    public function csrf(): ?string
    {
        $token = $this->post['csrf_token'] ?? $this->server['HTTP_X_CSRF_TOKEN'] ?? null;
        return is_scalar($token) ? (string) $token : null;
    }

    public function ip(): string
    {
        $valor = $this->server['REMOTE_ADDR'] ?? 'local';
        return preg_replace('/[^a-fA-F0-9:.]/', '', (string) $valor) ?: 'local';
    }

    public function agente(): string
    {
        return substr(FiltroTexto::texto((string) ($this->server['HTTP_USER_AGENT'] ?? '')), 0, 180);
    }
}
