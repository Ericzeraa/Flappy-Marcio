<?php

namespace Sistema\Base;

use InvalidArgumentException;

class Validador
{
    public static function usuarioSenha(string $usuario, string $senha): void
    {
        if (mb_strlen($usuario, 'UTF-8') < 3) {
            throw new InvalidArgumentException('O usuário precisa ter pelo menos 3 caracteres.');
        }
        if (mb_strlen($usuario, 'UTF-8') > 24) {
            throw new InvalidArgumentException('O usuário pode ter no máximo 24 caracteres.');
        }
        if (!preg_match('/^[a-z0-9_.-]+$/', $usuario)) {
            throw new InvalidArgumentException('Use apenas letras, números, ponto, hífen ou underline.');
        }
        if (strlen($senha) < 4) {
            throw new InvalidArgumentException('A senha precisa ter pelo menos 4 caracteres.');
        }
        if (strlen($senha) > 40) {
            throw new InvalidArgumentException('A senha pode ter no máximo 40 caracteres.');
        }
        if (in_array($usuario, ['admin', 'administrador', 'root'], true)) {
            throw new InvalidArgumentException('Escolha outro nome de usuário.');
        }
    }

    public static function partida(int $pontos, int $fase, float $duracao, float $velocidade): void
    {
        if ($pontos < 0 || $fase < 1 || $duracao < 0 || $velocidade < 1) {
            throw new InvalidArgumentException('Dados da partida inválidos.');
        }
        if ($pontos > 99999 || $fase > 999 || $duracao > 7200 || $velocidade > 100) {
            throw new InvalidArgumentException('Dados da partida fora do limite permitido.');
        }
    }

    public static function numeroConfig(string $valor, float $min, float $max): float
    {
        $valor = str_replace(',', '.', $valor);
        if (!is_numeric($valor)) {
            throw new InvalidArgumentException('Configuração numérica inválida.');
        }
        $numero = (float) $valor;
        if ($numero < $min || $numero > $max) {
            throw new InvalidArgumentException('Configuração fora da faixa segura.');
        }
        return $numero;
    }
}
