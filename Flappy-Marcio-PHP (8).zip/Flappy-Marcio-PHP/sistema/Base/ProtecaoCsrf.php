<?php

namespace Sistema\Base;

class ProtecaoCsrf
{
    public static function token(): string
    {
        Sessao::start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function validar(?string $token): bool
    {
        Sessao::start();
        return is_string($token) && isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public static function campo(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . FiltroTexto::html(self::token()) . '">';
    }
}
