<?php

namespace Sistema\Base;

use PDO;
use PDOException;
use RuntimeException;

class Conexao
{
    private static ?PDO $pdo = null;

    public static function pdo(callable $prepararBanco): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        try {
            self::$pdo = self::novaConexao(true);
            $prepararBanco(self::$pdo);
            return self::$pdo;
        } catch (PDOException $erro) {
            try {
                $base = self::novaConexao(false);
                $base->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                self::$pdo = self::novaConexao(true);
                $prepararBanco(self::$pdo);
                return self::$pdo;
            } catch (PDOException $novoErro) {
                throw new RuntimeException('MySQL indisponível. Confira Apache e MySQL no XAMPP.');
            }
        }
    }

    private static function novaConexao(bool $comBanco): PDO
    {
        $dsn = 'mysql:host=' . DB_HOST . ($comBanco ? ';dbname=' . DB_NAME : '') . ';charset=' . DB_CHARSET;
        return new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
}
