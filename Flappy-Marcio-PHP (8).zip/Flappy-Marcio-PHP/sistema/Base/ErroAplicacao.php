<?php

namespace Sistema\Base;

use RuntimeException;

class ErroAplicacao extends RuntimeException
{
    public function __construct(string $message, private int $status = 400)
    {
        parent::__construct($message);
    }

    public function status(): int
    {
        return $this->status;
    }
}
