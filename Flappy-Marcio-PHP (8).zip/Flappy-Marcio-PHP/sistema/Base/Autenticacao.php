<?php

namespace Sistema\Base;

class Autenticacao
{
    public static function gerarSenha(string $senha): string
    {
        return password_hash($senha, PASSWORD_DEFAULT);
    }

    public static function conferirSenha(string $senha, ?string $hash): bool
    {
        return $hash !== null && $hash !== '' && password_verify($senha, $hash);
    }

    public static function iniciarJogador(int $id): void
    {
        Sessao::renovar();
        Sessao::set('jogador_id', $id);
    }

    public static function sairJogador(): void
    {
        Sessao::remove('jogador_id');
    }
}
