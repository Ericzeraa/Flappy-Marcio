<?php

namespace Sistema\Base;

class Sessao
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        if (!headers_sent()) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path' => '/',
                'secure' => self::https(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }

        session_start();
    }

    public static function get(string $chave, mixed $padrao = null): mixed
    {
        self::start();
        return $_SESSION[$chave] ?? $padrao;
    }

    public static function set(string $chave, mixed $valor): void
    {
        self::start();
        $_SESSION[$chave] = $valor;
    }

    public static function remove(string $chave): void
    {
        self::start();
        unset($_SESSION[$chave]);
    }

    public static function renovar(): void
    {
        self::start();
        session_regenerate_id(true);
    }

    private static function https(): bool
    {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? null) === '443');
    }
}
