<?php

namespace Sistema\Entradas;

use Sistema\Base\Requisicao;
use Sistema\Regras\CatalogoJogo;
use Sistema\Regras\Partida;
use InvalidArgumentException;

class EntradaPartida
{
    public function __construct(
        public readonly int $pontos,
        public readonly int $fase,
        public readonly float $duracao,
        public readonly float $velocidade,
        public readonly string $dificuldade,
        public readonly string $skin,
        public readonly string $token
    ) {}

    public static function daRequisicao(Requisicao $request): self
    {
        $pontos = $request->postInt('pontos');
        $fase = $request->postInt('fase');
        $duracao = $request->postFloat('duracao');
        $velocidade = $request->postFloat('velocidade');
        $token = trim($request->postTexto('token_partida'));

        if ($pontos === null || $fase === null || $duracao === null || $velocidade === null) {
            throw new InvalidArgumentException('Dados da partida inválidos.');
        }

        return new self(
            max(0, $pontos),
            max(1, $fase),
            max(0, $duracao),
            max(1, $velocidade),
            CatalogoJogo::dificuldadeValida($request->postTexto('dificuldade', 'normal')),
            CatalogoJogo::skinValida($request->postTexto('skin', 'classica')),
            $token
        );
    }

    public function partida(int $jogadorId): Partida
    {
        return Partida::criar($jogadorId, $this->pontos, $this->fase, $this->duracao, $this->velocidade, $this->dificuldade, $this->skin, $this->token);
    }
}
