<?php

namespace Sistema\Entradas;

use Sistema\Base\Requisicao;
use Sistema\Base\FiltroTexto;
use Sistema\Base\Validador;

class EntradaAcesso
{
    public function __construct(public readonly string $usuario, public readonly string $senha) {}

    public static function daRequisicao(Requisicao $request): self
    {
        $usuario = FiltroTexto::usuario($request->postTexto('usuario'));
        $senha = $request->postTexto('senha');
        Validador::usuarioSenha($usuario, $senha);
        return new self($usuario, $senha);
    }
}
