<?php

namespace Sistema\Controle;

use Sistema\Base\ErroAplicacao;
use Sistema\Base\Autenticacao;
use Sistema\Base\ProtecaoCsrf;
use Sistema\Base\Requisicao;
use Sistema\Entradas\EntradaAcesso;
use Sistema\Entradas\EntradaPartida;
use Sistema\Repositorios\RepositorioAuditoria;
use Sistema\Repositorios\RepositorioTokenPartida;
use Sistema\Repositorios\TentativasLogin;
use Sistema\Servicos\ValidadorPartida;
use Sistema\Servicos\ServicoTokenPartida;
use Sistema\Servicos\SegurancaLogin;
use InvalidArgumentException;
use PDO;
use Throwable;

class ControleJogo
{
    private const POST_COM_CSRF = ['registrar', 'login', 'iniciar_partida', 'salvar'];

    private PDO $pdo;
    private Requisicao $request;
    private \Jogador $jogadores;
    private \Ranking $ranking;
    private ServicoTokenPartida $partidas;
    private ValidadorPartida $integridade;
    private RepositorioAuditoria $auditoria;
    private SegurancaLogin $seguranca;

    public function __construct(?Requisicao $request = null)
    {
        $this->pdo = pdo();
        $this->request = $request ?? Requisicao::capturar();
        $this->jogadores = new \Jogador();
        $this->ranking = new \Ranking();
        $this->partidas = new ServicoTokenPartida(new RepositorioTokenPartida($this->pdo));
        $this->integridade = new ValidadorPartida();
        $this->auditoria = new RepositorioAuditoria($this->pdo);
        $this->seguranca = new SegurancaLogin(new TentativasLogin($this->pdo));
    }

    public function executar(): void
    {
        $acao = $this->request->acao();

        try {
            $this->validarEntrada($acao);

            match ($acao) {
                'sessao' => $this->sessao(),
                'registrar' => $this->registrar(),
                'login' => $this->login(),
                'sair' => $this->sair(),
                'config' => $this->config(),
                'listar' => $this->listar(),
                'historico' => $this->historico(),
                'estatisticas' => $this->estatisticas(),
                'jogador' => $this->jogador(),
                'iniciar_partida' => $this->iniciarPartida(),
                'salvar' => $this->salvar(),
                default => resposta_json(['ok' => false, 'mensagem' => 'Ação inválida.'], 400),
            };
        } catch (Throwable $erro) {
            $codigo = $erro instanceof ErroAplicacao ? $erro->status() : ($erro instanceof InvalidArgumentException ? 400 : 500);
            $mensagem = $codigo < 500 ? $erro->getMessage() : 'Não foi possível processar a solicitação.';
            resposta_json(['ok' => false, 'mensagem' => $mensagem], $codigo);
        }
    }

    private function validarEntrada(string $acao): void
    {
        if (in_array($acao, self::POST_COM_CSRF, true) && $this->request->metodo() !== 'POST') {
            throw new ErroAplicacao('Método não permitido para esta ação.', 405);
        }

        if ($this->request->metodo() === 'POST' && in_array($acao, self::POST_COM_CSRF, true) && !ProtecaoCsrf::validar($this->request->csrf())) {
            throw new InvalidArgumentException('Sessão expirada. Atualize a página e tente novamente.');
        }
    }

    private function sessao(): void
    {
        $jogador = jogador_sessao();
        if (!$jogador) {
            resposta_json(['ok' => true, 'logado' => false, 'jogador' => null, 'perfil' => null, 'conquistas' => [], 'missoes' => missoes_do_dia(), 'skins' => skins_jogo()]);
        }
        $this->responderJogadorLogado($jogador);
    }

    private function registrar(): void
    {
        $input = EntradaAcesso::daRequisicao($this->request);
        $this->seguranca->registrarTentativa('registrar:' . $this->request->ip() . ':' . $input->usuario, 'registrar_jogador', $this->request->ip(), 8, 15);
        $jogador = $this->jogadores->criar($input->usuario, $input->senha);
        Autenticacao::iniciarJogador((int) $jogador['id']);
        $this->auditoria->registrar('jogador_registrado', (int) $jogador['id'], ['usuario' => $jogador['nome']], $this->request->ip(), $this->request->agente());
        resposta_json(['ok' => true, 'mensagem' => 'Conta criada.', 'jogador' => ['id' => (int) $jogador['id'], 'nome' => $jogador['nome']], 'perfil' => perfil_jogador((int) $jogador['id']), 'conquistas' => conquistas_jogador((int) $jogador['id']), 'posicao' => posicao_jogador((int) $jogador['id'])]);
    }

    private function login(): void
    {
        $input = EntradaAcesso::daRequisicao($this->request);
        $this->seguranca->registrarTentativa('login:' . $this->request->ip() . ':' . $input->usuario, 'login_jogador', $this->request->ip(), 10, 15);
        $jogador = $this->jogadores->entrar($input->usuario, $input->senha);
        Autenticacao::iniciarJogador((int) $jogador['id']);
        $this->auditoria->registrar('login_jogador', (int) $jogador['id'], ['usuario' => $jogador['nome']], $this->request->ip(), $this->request->agente());
        resposta_json(['ok' => true, 'mensagem' => 'Login realizado.', 'jogador' => ['id' => (int) $jogador['id'], 'nome' => $jogador['nome'], 'skin' => $jogador['skin']], 'perfil' => perfil_jogador((int) $jogador['id']), 'conquistas' => conquistas_jogador((int) $jogador['id']), 'posicao' => posicao_jogador((int) $jogador['id'])]);
    }

    private function sair(): void
    {
        $jogador = jogador_sessao();
        if ($jogador) {
            $this->auditoria->registrar('logout_jogador', (int) $jogador['id'], [], $this->request->ip(), $this->request->agente());
        }
        Autenticacao::sairJogador();
        resposta_json(['ok' => true]);
    }

    private function config(): void
    {
        resposta_json(['ok' => true, 'config' => configuracoes_jogo(), 'dificuldades' => dificuldades_jogo(), 'missoes' => missoes_do_dia(), 'estatisticas' => estatisticas_gerais(), 'skins' => skins_jogo()]);
    }

    private function listar(): void
    {
        resposta_json(['ok' => true, 'ranking' => $this->ranking->listar($this->request->getTexto('dificuldade', 'geral'), $this->request->getTexto('periodo', 'geral'), 10)]);
    }

    private function historico(): void
    {
        $stmt = $this->pdo->query('SELECT j.nome, p.pontos, p.fase, p.duracao_seg, p.velocidade_final, p.dificuldade, p.criado_em data
            FROM partidas p
            JOIN jogadores j ON j.id = p.jogador_id
            ORDER BY p.criado_em DESC
            LIMIT 8');
        resposta_json(['ok' => true, 'historico' => $stmt->fetchAll()]);
    }

    private function estatisticas(): void
    {
        resposta_json(['ok' => true, 'estatisticas' => estatisticas_gerais(), 'skins' => skins_jogo()]);
    }

    private function jogador(): void
    {
        $jogador = jogador_sessao();
        if (!$jogador) {
            resposta_json(['ok' => true, 'logado' => false, 'recorde' => 0, 'posicao' => null, 'conquistas' => [], 'perfil' => null, 'missoes' => missoes_do_dia(), 'skins' => skins_jogo()]);
        }
        $this->responderJogadorLogado($jogador);
    }

    private function iniciarPartida(): void
    {
        $jogador = jogador_sessao();
        if (!$jogador) {
            resposta_json(['ok' => false, 'mensagem' => 'Faça login para iniciar a partida.'], 401);
        }

        $partida = $this->partidas->iniciar(
            (int) $jogador['id'],
            $this->request->postTexto('dificuldade', 'normal'),
            $this->request->postTexto('skin', 'classica')
        );

        $this->auditoria->registrar('partida_iniciada', (int) $jogador['id'], ['dificuldade' => $partida['dificuldade'], 'skin' => $partida['skin']], $this->request->ip(), $this->request->agente());
        resposta_json(['ok' => true, 'partida' => $partida]);
    }

    private function salvar(): void
    {
        $jogador = jogador_sessao();
        if (!$jogador) {
            resposta_json(['ok' => false, 'mensagem' => 'Faça login para salvar a partida.'], 401);
        }

        $jogadorId = (int) $jogador['id'];
        $input = EntradaPartida::daRequisicao($this->request);
        $registroToken = $this->partidas->validarUso($jogadorId, $input->token, $input->dificuldade, $input->skin);
        $partida = $input->partida($jogadorId);

        $this->integridade->validar($partida, $registroToken, configuracoes_jogo());
        $resultado = $this->ranking->salvar($partida);
        $this->partidas->consumir($registroToken);

        $this->auditoria->registrar('partida_salva', $jogadorId, [
            'pontos' => $partida->pontos,
            'fase' => $partida->fase,
            'duracao' => $partida->duracao,
            'dificuldade' => $partida->dificuldade,
            'skin' => $partida->skin,
        ], $this->request->ip(), $this->request->agente());

        $posicao = $resultado['posicao'];
        resposta_json([
            'ok' => true,
            'recorde' => $resultado['recorde'],
            'fase' => $resultado['fase'],
            'melhorou' => $resultado['melhorou'],
            'posicao' => $posicao,
            'podio' => $posicao !== null && $posicao <= 3,
            'conquistas' => $resultado['conquistas'],
            'missoesConcluidas' => $resultado['missoes'],
            'perfil' => perfil_jogador($jogadorId),
            'estatisticas' => estatisticas_gerais(),
            'skins' => skins_jogo(),
        ]);
    }

    private function responderJogadorLogado(array $jogador): void
    {
        $jogadorId = (int) $jogador['id'];
        $perfil = perfil_jogador($jogadorId);
        resposta_json([
            'ok' => true,
            'logado' => true,
            'jogador' => ['id' => $jogadorId, 'nome' => $jogador['nome'], 'skin' => $jogador['skin']],
            'recorde' => $perfil['melhor'],
            'posicao' => posicao_jogador($jogadorId),
            'perfil' => $perfil,
            'conquistas' => conquistas_jogador($jogadorId),
            'missoes' => missoes_do_dia(),
            'skins' => skins_jogo(),
        ]);
    }
}
