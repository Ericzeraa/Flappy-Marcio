<?php
require_once __DIR__ . '/configuracao.php';
require_once __DIR__ . '/Suporte/Carregador.php';

require_once __DIR__ . '/Funcoes/apoio.php';
require_once __DIR__ . '/Funcoes/banco.php';
require_once __DIR__ . '/Funcoes/jogo.php';
require_once __DIR__ . '/Funcoes/jogadores.php';
require_once __DIR__ . '/Funcoes/ranking.php';
require_once __DIR__ . '/Funcoes/exportacao.php';

require_once __DIR__ . '/Modelos/Jogador.php';
require_once __DIR__ . '/Modelos/Ranking.php';
require_once __DIR__ . '/Modelos/PainelAdministrativo.php';
