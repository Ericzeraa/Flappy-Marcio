<?php

namespace Sistema\Regras;

use Sistema\Base\Validador;
use InvalidArgumentException;

class Partida
{
    public function __construct(
        public readonly int $jogadorId,
        public readonly int $pontos,
        public readonly int $fase,
        public readonly float $duracao,
        public readonly float $velocidade,
        public readonly string $dificuldade,
        public readonly string $skin,
        public readonly ?string $token = null
    ) {
        Validador::partida($pontos, $fase, $duracao, $velocidade);
        $this->validarCoerencia();
    }

    public static function criar(
        int $jogadorId,
        int $pontos,
        int $fase,
        float $duracao,
        float $velocidade,
        string $dificuldade,
        string $skin,
        ?string $token = null
    ): self {
        return new self(
            $jogadorId,
            $pontos,
            max(1, $fase),
            max(0, $duracao),
            max(1, $velocidade),
            CatalogoJogo::dificuldadeValida($dificuldade),
            CatalogoJogo::skinValida($skin),
            $token !== null ? trim($token) : null
        );
    }

    private function validarCoerencia(): void
    {
        if ($this->pontos > 0 && $this->duracao < 0.3) {
            throw new InvalidArgumentException('A duração da partida não combina com a pontuação enviada.');
        }

        $limiteFase = max(10, $this->pontos + 5);
        if ($this->fase > $limiteFase) {
            throw new InvalidArgumentException('A fase enviada não combina com a pontuação da partida.');
        }
    }
}
