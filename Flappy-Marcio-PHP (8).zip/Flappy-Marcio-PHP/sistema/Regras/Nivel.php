<?php

namespace Sistema\Regras;

class Nivel
{
    public static function calcular(int $xp): array
    {
        $nivel = max(1, intdiv(max(0, $xp), 100) + 1);
        $titulos = [1 => 'Iniciante', 2 => 'Treinando voo', 3 => 'Voador', 4 => 'Sobrevivente', 5 => 'Piloto', 7 => 'Mestre dos canos', 10 => 'Lenda'];
        $titulo = 'Lenda';
        foreach ($titulos as $minimo => $nome) {
            if ($nivel >= $minimo) {
                $titulo = $nome;
            }
        }

        return ['xp' => $xp, 'nivel' => $nivel, 'titulo' => $titulo, 'atual' => $xp % 100, 'proximo' => 100];
    }
}
