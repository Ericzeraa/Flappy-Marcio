<?php

use Sistema\Repositorios\RepositorioAdministrativo;
use Sistema\Repositorios\RepositorioConfiguracao;
use Sistema\Repositorios\RepositorioJogador;
use Sistema\Servicos\ServicoAdministrativo;

class PainelAdministrativo
{
    private ServicoAdministrativo $servico;

    public function __construct()
    {
        $pdo = pdo();
        $this->servico = new ServicoAdministrativo(new RepositorioAdministrativo($pdo), new RepositorioConfiguracao($pdo), new RepositorioJogador($pdo), $pdo);
    }

    public function autenticar(string $usuario, string $senha): bool
    {
        return $this->servico->autenticar($usuario, $senha);
    }

    public function salvarConfiguracoes(array $dados): void
    {
        $this->servico->salvarConfiguracoes($dados);
    }

    public function limparRanking(): void
    {
        $this->servico->limparRanking();
    }

    public function excluirJogador(int $id): void
    {
        $this->servico->excluirJogador($id);
    }

    public function dadosPainel(): array
    {
        return $this->servico->dadosPainel();
    }
}
