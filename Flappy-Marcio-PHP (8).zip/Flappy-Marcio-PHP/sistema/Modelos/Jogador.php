<?php

use Sistema\Repositorios\RepositorioJogador;
use Sistema\Repositorios\RepositorioRanking;
use Sistema\Servicos\ServicoJogador;

class Jogador
{
    private ServicoJogador $servico;

    public function __construct()
    {
        $pdo = pdo();
        $this->servico = new ServicoJogador(new RepositorioJogador($pdo), new RepositorioRanking($pdo));
    }

    public function criar(string $usuario, string $senha): array
    {
        return $this->servico->criar($usuario, $senha);
    }

    public function entrar(string $usuario, string $senha): array
    {
        return $this->servico->entrar($usuario, $senha);
    }

    public function buscarPorId(int $id): array
    {
        return $this->servico->buscarPorId($id);
    }

    public function perfil(int $id): array
    {
        return $this->servico->perfil($id);
    }
}
