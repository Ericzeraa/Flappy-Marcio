<?php

use Sistema\Repositorios\RepositorioJogador;
use Sistema\Repositorios\RepositorioRanking;
use Sistema\Servicos\ServicoPontuacao;
use Sistema\Servicos\ServicoJogador;
use Sistema\Servicos\ServicoRanking;
use Sistema\Regras\Partida;

class Ranking
{
    private ServicoRanking $servico;

    public function __construct()
    {
        $pdo = pdo();
        $ranking = new RepositorioRanking($pdo);
        $jogadores = new RepositorioJogador($pdo);
        $jogadorService = new ServicoJogador($jogadores, $ranking);
        $gamificacao = new ServicoPontuacao($ranking, $jogadorService);
        $this->servico = new ServicoRanking($ranking, $jogadores, $gamificacao);
    }

    public function listar(string $dificuldade = 'geral', string $periodo = 'geral', int $limite = 10): array
    {
        return $this->servico->listar($dificuldade, $periodo, $limite);
    }

    public function salvarPartida(int $jogadorId, int $pontos, int $fase, float $duracao, float $velocidade, string $dificuldade, string $skin): array
    {
        return $this->servico->salvarPartida($jogadorId, $pontos, $fase, $duracao, $velocidade, $dificuldade, $skin);
    }

    public function salvar(Partida $partida): array
    {
        return $this->servico->salvar($partida);
    }
}
