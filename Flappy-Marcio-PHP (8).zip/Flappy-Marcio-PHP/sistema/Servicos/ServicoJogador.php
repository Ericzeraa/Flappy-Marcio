<?php

namespace Sistema\Servicos;

use Sistema\Base\Autenticacao;
use Sistema\Base\FiltroTexto;
use Sistema\Base\Validador;
use Sistema\Regras\Nivel;
use Sistema\Repositorios\RepositorioJogador;
use Sistema\Repositorios\RepositorioRanking;
use InvalidArgumentException;
use RuntimeException;

class ServicoJogador
{
    public function __construct(private RepositorioJogador $jogadores, private RepositorioRanking $ranking) {}

    public function criar(string $usuario, string $senha): array
    {
        $usuario = FiltroTexto::usuario($usuario);
        Validador::usuarioSenha($usuario, $senha);

        if ($this->jogadores->existeUsuario($usuario)) {
            throw new InvalidArgumentException('Esse usuário já existe.');
        }

        return $this->jogadores->criar($usuario, Autenticacao::gerarSenha($senha));
    }

    public function entrar(string $usuario, string $senha): array
    {
        $usuario = FiltroTexto::usuario($usuario);
        $jogador = $this->jogadores->buscarPorUsuario($usuario);

        if (!$jogador || !Autenticacao::conferirSenha($senha, $jogador['senha_hash'] ?? null)) {
            throw new InvalidArgumentException('Usuário ou senha inválidos.');
        }

        return $jogador;
    }

    public function buscarPorId(int $id): array
    {
        $jogador = $this->jogadores->buscarPorId($id);
        if (!$jogador) {
            throw new RuntimeException('Jogador não encontrado.');
        }
        return $jogador;
    }

    public function perfil(int $jogadorId): array
    {
        $dados = $this->ranking->perfilBruto($jogadorId);
        $conquistas = $this->ranking->totalConquistas($jogadorId);
        $missoesHoje = $this->ranking->missoesHoje($jogadorId);

        $partidas = (int) ($dados['partidas'] ?? 0);
        $melhor = (int) ($dados['melhor'] ?? 0);
        $fase = (int) ($dados['fase'] ?? 1);
        $pontosTotal = (int) ($dados['pontos_total'] ?? 0);
        $xp = ($partidas * 12) + ($pontosTotal * 4) + ($fase * 15) + ($conquistas * 30) + ($missoesHoje * 10);
        $nivel = Nivel::calcular($xp);

        return [
            'partidas' => $partidas,
            'melhor' => $melhor,
            'fase' => $fase,
            'media' => round((float) ($dados['media'] ?? 0), 1),
            'tempo' => round((float) ($dados['tempo'] ?? 0), 1),
            'conquistas' => $conquistas,
            'missoesHoje' => $missoesHoje,
            'xp' => $nivel['xp'],
            'nivel' => $nivel['nivel'],
            'tituloNivel' => $nivel['titulo'],
            'xpAtual' => $nivel['atual'],
            'xpProximo' => $nivel['proximo'],
        ];
    }
}
