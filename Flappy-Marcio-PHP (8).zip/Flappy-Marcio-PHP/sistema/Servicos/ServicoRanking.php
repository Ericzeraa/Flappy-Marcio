<?php

namespace Sistema\Servicos;

use Sistema\Regras\CatalogoJogo;
use Sistema\Regras\Partida;
use Sistema\Repositorios\RepositorioJogador;
use Sistema\Repositorios\RepositorioRanking;

class ServicoRanking
{
    public function __construct(private RepositorioRanking $ranking, private RepositorioJogador $jogadores, private ServicoPontuacao $gamificacao) {}

    public function listar(string $dificuldade = 'geral', string $periodo = 'geral', int $limite = 10): array
    {
        $dificuldade = $dificuldade === 'geral' ? 'geral' : CatalogoJogo::dificuldadeValida($dificuldade);
        $periodo = in_array($periodo, ['geral', 'hoje', 'semana'], true) ? $periodo : 'geral';
        return $this->ranking->listar($dificuldade, $periodo, $limite);
    }

    public function salvarPartida(int $jogadorId, int $pontos, int $fase, float $duracao, float $velocidade, string $dificuldade, string $skin): array
    {
        return $this->salvar(Partida::criar($jogadorId, $pontos, $fase, $duracao, $velocidade, $dificuldade, $skin));
    }

    public function salvar(Partida $partida): array
    {
        return $this->ranking->transacao(function () use ($partida): array {
            $this->jogadores->atualizarSkin($partida->jogadorId, $partida->skin);
            $this->ranking->registrarPartida($partida->jogadorId, $partida->pontos, $partida->fase, $partida->duracao, $partida->velocidade, $partida->dificuldade, $partida->skin);

            $atual = $this->ranking->recordeDaDificuldade($partida->jogadorId, $partida->dificuldade);
            $melhorou = !$atual || $partida->pontos > (int) $atual['pontos'];
            if ($melhorou) {
                $this->ranking->salvarRecorde($partida->jogadorId, $partida->dificuldade, $partida->pontos, $partida->fase, $partida->duracao, $partida->velocidade);
            }

            $posicao = $this->ranking->posicao($partida->jogadorId);
            $novas = $this->gamificacao->liberarConquistas($partida->jogadorId, $partida->pontos, $partida->fase, $partida->duracao, $partida->dificuldade, $posicao);
            $missoes = $this->gamificacao->concluirMissoes($partida->jogadorId, $partida->pontos, $partida->fase, $partida->duracao, $partida->dificuldade);
            $recorde = $this->ranking->melhorRecorde($partida->jogadorId);

            return [
                'recorde' => (int) $recorde['pontos'],
                'fase' => (int) $recorde['fase'],
                'melhorou' => $melhorou,
                'posicao' => $posicao,
                'conquistas' => $novas,
                'missoes' => $missoes,
            ];
        });
    }
}
