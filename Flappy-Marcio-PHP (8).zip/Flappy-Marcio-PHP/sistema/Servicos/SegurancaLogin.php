<?php

namespace Sistema\Servicos;

use Sistema\Repositorios\TentativasLogin;
use InvalidArgumentException;

class SegurancaLogin
{
    public function __construct(private TentativasLogin $tentativas) {}

    public function registrarTentativa(string $chave, string $contexto, string $ip, int $limite, int $janelaMinutos): void
    {
        if ($this->tentativas->contar($chave, $janelaMinutos) >= $limite) {
            throw new InvalidArgumentException('Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente novamente.');
        }

        $this->tentativas->registrar($chave, $contexto, $ip);
    }
}
