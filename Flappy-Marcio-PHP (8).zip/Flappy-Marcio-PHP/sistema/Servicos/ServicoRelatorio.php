<?php

namespace Sistema\Servicos;

use Sistema\Repositorios\RepositorioAdministrativo;
use PDO;

class ServicoRelatorio
{
    public function __construct(private PDO $pdo, private RepositorioAdministrativo $admin) {}

    public function indicadores(): array
    {
        $ranking = $this->admin->rankingCompleto();
        $partidas = $this->admin->ultimasPartidas();
        $porDificuldade = $this->admin->desempenhoPorDificuldade();

        return [
            'totalRanking' => count($ranking),
            'ultimasPartidas' => count($partidas),
            'modosUsados' => count($porDificuldade),
            'mediaTempo' => $this->mediaTempo(),
            'aproveitamentoMissoesHoje' => $this->missoesHoje(),
        ];
    }

    private function mediaTempo(): float
    {
        $valor = $this->pdo->query('SELECT COALESCE(AVG(duracao_seg), 0) FROM partidas')->fetchColumn();
        return round((float) $valor, 1);
    }

    private function missoesHoje(): int
    {
        $valor = $this->pdo->query('SELECT COUNT(*) FROM missoes_concluidas WHERE data_ref = CURDATE()')->fetchColumn();
        return (int) $valor;
    }
}
