<?php

namespace Sistema\Servicos;

use Sistema\Regras\CatalogoJogo;
use Sistema\Repositorios\RepositorioTokenPartida;
use InvalidArgumentException;

class ServicoTokenPartida
{
    public function __construct(private RepositorioTokenPartida $tokens) {}

    public function iniciar(int $jogadorId, string $dificuldade, string $skin): array
    {
        $dificuldade = CatalogoJogo::dificuldadeValida($dificuldade);
        $skin = CatalogoJogo::skinValida($skin);
        $token = bin2hex(random_bytes(24));
        $this->tokens->criar($jogadorId, $token, $dificuldade, $skin);

        return [
            'token' => $token,
            'dificuldade' => $dificuldade,
            'skin' => $skin,
            'expiraEmMinutos' => 30,
        ];
    }

    public function validarUso(int $jogadorId, ?string $token, string $dificuldade, string $skin): array
    {
        $token = trim((string) $token);
        if ($token === '' || !preg_match('/^[a-f0-9]{48}$/', $token)) {
            throw new InvalidArgumentException('Token da partida inválido. Reinicie o jogo e tente novamente.');
        }

        $registro = $this->tokens->buscarValido($jogadorId, $token);
        if (!$registro) {
            throw new InvalidArgumentException('Essa partida expirou ou já foi registrada.');
        }

        if ($registro['dificuldade'] !== CatalogoJogo::dificuldadeValida($dificuldade) || $registro['skin'] !== CatalogoJogo::skinValida($skin)) {
            throw new InvalidArgumentException('Os dados da partida não conferem com o início registrado.');
        }

        return $registro;
    }

    public function consumir(array $registro): void
    {
        $this->tokens->marcarUsado((int) $registro['id']);
    }
}
