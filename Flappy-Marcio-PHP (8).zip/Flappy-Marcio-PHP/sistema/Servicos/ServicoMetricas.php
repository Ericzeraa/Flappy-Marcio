<?php

namespace Sistema\Servicos;

use PDO;
use Throwable;

class ServicoMetricas
{
    public function __construct(private PDO $pdo) {}

    public function gerais(): array
    {
        try {
            $resumo = $this->pdo->query('SELECT COUNT(*) total, COALESCE(AVG(pontos), 0) media, COALESCE(AVG(duracao_seg), 0) tempo_medio, COALESCE(MAX(pontos), 0) maior, COALESCE(MAX(fase), 1) fase FROM partidas')->fetch();
            $jogadores = $this->pdo->query('SELECT COUNT(*) total FROM jogadores')->fetch();
            $campeao = $this->pdo->query('SELECT j.nome, p.pontos FROM pontuacoes p JOIN jogadores j ON j.id = p.jogador_id ORDER BY p.pontos DESC, p.atualizado_em ASC LIMIT 1')->fetch();
            $dif = $this->pdo->query('SELECT dificuldade, COUNT(*) total FROM partidas GROUP BY dificuldade ORDER BY total DESC LIMIT 1')->fetch();
            $hoje = $this->pdo->query('SELECT COUNT(*) partidas, COALESCE(MAX(pontos), 0) maior FROM partidas WHERE DATE(criado_em) = CURDATE()')->fetch();
            $ativos = $this->pdo->query('SELECT COUNT(DISTINCT jogador_id) total FROM partidas WHERE criado_em >= DATE_SUB(NOW(), INTERVAL 7 DAY)')->fetch();
            $maisAtivo = $this->pdo->query('SELECT j.nome, COUNT(*) total FROM partidas p JOIN jogadores j ON j.id = p.jogador_id GROUP BY j.id, j.nome ORDER BY total DESC, j.nome ASC LIMIT 1')->fetch();

            return [
                'partidas' => (int) ($resumo['total'] ?? 0),
                'jogadores' => (int) ($jogadores['total'] ?? 0),
                'media' => round((float) ($resumo['media'] ?? 0), 1),
                'maior' => (int) ($resumo['maior'] ?? 0),
                'fase' => (int) ($resumo['fase'] ?? 1),
                'campeao' => $campeao['nome'] ?? 'Aguardando',
                'pontos_campeao' => (int) ($campeao['pontos'] ?? 0),
                'dificuldade' => $dif['dificuldade'] ?? 'normal',
                'partidas_hoje' => (int) ($hoje['partidas'] ?? 0),
                'maior_hoje' => (int) ($hoje['maior'] ?? 0),
                'jogadores_ativos' => (int) ($ativos['total'] ?? 0),
                'mais_ativo' => $maisAtivo['nome'] ?? 'Aguardando',
                'tempo_medio' => round((float) ($resumo['tempo_medio'] ?? 0), 1),
            ];
        } catch (Throwable) {
            return [
                'partidas' => 0,
                'jogadores' => 0,
                'media' => 0,
                'maior' => 0,
                'fase' => 1,
                'campeao' => 'MySQL offline',
                'pontos_campeao' => 0,
                'dificuldade' => 'normal',
                'partidas_hoje' => 0,
                'maior_hoje' => 0,
                'jogadores_ativos' => 0,
                'mais_ativo' => 'Aguardando',
                'tempo_medio' => 0,
            ];
        }
    }
}
