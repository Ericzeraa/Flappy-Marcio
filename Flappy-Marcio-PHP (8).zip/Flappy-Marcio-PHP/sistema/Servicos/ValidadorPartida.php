<?php

namespace Sistema\Servicos;

use Sistema\Regras\Partida;
use DateTimeImmutable;
use InvalidArgumentException;

class ValidadorPartida
{
    public function validar(Partida $partida, array $token, array $config): void
    {
        $this->validarRelogioDaPartida($partida, $token);
        $this->validarRitmoDaPontuacao($partida);
        $this->validarFase($partida, $config);
    }

    private function validarRelogioDaPartida(Partida $partida, array $token): void
    {
        $inicio = new DateTimeImmutable((string) $token['criado_em']);
        $agora = new DateTimeImmutable();
        $tempoReal = max(0, $agora->getTimestamp() - $inicio->getTimestamp());

        if ($partida->duracao > $tempoReal + 12) {
            throw new InvalidArgumentException('O tempo da partida não confere com o início registrado.');
        }
    }

    private function validarRitmoDaPontuacao(Partida $partida): void
    {
        if ($partida->pontos === 0) {
            return;
        }

        if ($partida->duracao < 0.4) {
            throw new InvalidArgumentException('A partida terminou rápido demais para a pontuação enviada.');
        }

        $pontosPorSegundo = $partida->pontos / max(1, $partida->duracao);
        if ($pontosPorSegundo > 3.8) {
            throw new InvalidArgumentException('A pontuação enviada passou do ritmo esperado do jogo.');
        }
    }

    private function validarFase(Partida $partida, array $config): void
    {
        $pontosPorFase = max(1, (int) round((float) ($config['pontos_por_fase'] ?? 6)));
        $faseEsperada = intdiv($partida->pontos, $pontosPorFase) + 1;

        if ($partida->fase > $faseEsperada + 1) {
            throw new InvalidArgumentException('A fase informada não acompanha a pontuação da partida.');
        }
    }
}
