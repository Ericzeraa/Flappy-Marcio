<?php

namespace Sistema\Servicos;

use Sistema\Regras\CatalogoJogo;
use Sistema\Repositorios\RepositorioRanking;

class ServicoPontuacao
{
    public function __construct(private RepositorioRanking $ranking, private ServicoJogador $jogadores) {}

    public function liberarConquistas(int $jogadorId, int $pontos, int $fase, float $duracao, string $dificuldade, ?int $posicao): array
    {
        $perfil = $this->jogadores->perfil($jogadorId);
        $regras = [
            ['primeiro_voo', 'Primeiro voo', 'Jogou pela primeira vez', true],
            ['fase_3', 'Pegou ritmo', 'Chegou na fase 3', $fase >= 3],
            ['fase_5', 'Pegou prática', 'Chegou na fase 5', $fase >= 5],
            ['dez_pontos', 'Fez 10 pontos', 'Fez pelo menos 10 pontos', $pontos >= 10],
            ['vinte_pontos', 'Mandou bem nos canos', 'Fez pelo menos 20 pontos', $pontos >= 20],
            ['um_minuto', 'Aguentou bem', 'Sobreviveu por 60 segundos', $duracao >= 60],
            ['modo_insano', 'Foi no insano', 'Jogou no modo insano', $dificuldade === 'insano'],
            ['podio', 'Pegou pódio', 'Ficou no top 3', $posicao !== null && $posicao <= 3],
            ['skin_azul', 'Azul liberada', 'Fez 8 pontos e liberou uma nova skin', $pontos >= 8],
            ['skin_dourada', 'Dourada liberada', 'Chegou na fase 4', $fase >= 4],
            ['skin_neon', 'Neon liberada', 'Jogou o suficiente para liberar o neon', $perfil['partidas'] >= 8],
        ];

        $novas = [];
        foreach ($regras as $regra) {
            if (!$regra[3]) {
                continue;
            }
            if ($this->ranking->inserirConquista($jogadorId, $regra[0], $regra[1], $regra[2])) {
                $novas[] = ['codigo' => $regra[0], 'titulo' => $regra[1], 'descricao' => $regra[2]];
            }
        }
        return $novas;
    }

    public function concluirMissoes(int $jogadorId, int $pontos, int $fase, float $duracao, string $dificuldade): array
    {
        $novas = [];
        $hoje = date('Y-m-d');
        foreach (CatalogoJogo::missoesDoDia() as $missao) {
            $ok = false;
            if ($missao['tipo'] === 'pontos') $ok = $pontos >= (int) $missao['meta'];
            if ($missao['tipo'] === 'fase') $ok = $fase >= (int) $missao['meta'];
            if ($missao['tipo'] === 'tempo') $ok = $duracao >= (float) $missao['meta'];
            if ($missao['tipo'] === 'dificuldade') $ok = in_array($dificuldade, ['dificil', 'insano'], true);

            if ($ok && $this->ranking->inserirMissao($jogadorId, $missao['codigo'], $missao['titulo'], $hoje)) {
                $novas[] = ['codigo' => $missao['codigo'], 'titulo' => $missao['titulo']];
            }
        }
        return $novas;
    }
}
