<?php

namespace Sistema\Servicos;

use Sistema\Base\Autenticacao;
use Sistema\Base\FiltroTexto;
use Sistema\Base\Validador;
use Sistema\Repositorios\RepositorioAdministrativo;
use Sistema\Repositorios\RepositorioConfiguracao;
use Sistema\Repositorios\RepositorioJogador;
use PDO;

class ServicoAdministrativo
{
    private const LIMITES_CONFIG = [
        'velocidade_inicial' => [1, 10],
        'aumento_fase' => [0, 2],
        'velocidade_maxima' => [1, 15],
        'pontos_por_fase' => [1, 30],
        'abertura_inicial' => [80, 400],
        'abertura_minima' => [60, 300],
        'gravidade' => [0.1, 2],
        'pulo' => [-20, -1],
    ];

    public function __construct(private RepositorioAdministrativo $admin, private RepositorioConfiguracao $config, private RepositorioJogador $jogadores, private ?PDO $pdo = null) {}

    public function autenticar(string $usuario, string $senha): bool
    {
        $usuario = FiltroTexto::usuario($usuario);
        $hash = $this->admin->senhaHash($usuario);
        return Autenticacao::conferirSenha($senha, $hash);
    }

    public function salvarConfiguracoes(array $dados): void
    {
        foreach ($this->config->chavesPermitidas() as $chave) {
            if (!isset($dados[$chave], self::LIMITES_CONFIG[$chave])) {
                continue;
            }
            [$min, $max] = self::LIMITES_CONFIG[$chave];
            $valor = Validador::numeroConfig((string) $dados[$chave], $min, $max);
            $this->config->salvar($chave, $valor);
        }
    }

    public function limparRanking(): void
    {
        $this->admin->limparDadosDoJogo();
    }

    public function excluirJogador(int $id): void
    {
        $this->jogadores->excluir($id);
    }

    public function dadosPainel(): array
    {
        return [
            'ranking' => $this->admin->rankingCompleto(),
            'partidas' => $this->admin->ultimasPartidas(),
            'conquistas' => $this->admin->ultimasConquistas(),
            'missoes' => $this->admin->ultimasMissoes(),
            'porDificuldade' => $this->admin->desempenhoPorDificuldade(),
            'auditoria' => $this->admin->auditoriaRecente(),
            'indicadoresTecnicos' => $this->pdo ? (new ServicoRelatorio($this->pdo, $this->admin))->indicadores() : [],
        ];
    }
}
