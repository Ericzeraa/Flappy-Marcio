<?php

function configuracoes_jogo(): array
{
    $config = [
        'velocidade_inicial' => 4.20,
        'aumento_fase' => 0.38,
        'velocidade_maxima' => 7.2,
        'pontos_por_fase' => 6,
        'abertura_inicial' => 210,
        'abertura_minima' => 168,
        'gravidade' => 0.46,
        'pulo' => -8.25
    ];

    try {
        foreach (pdo()->query('SELECT chave, valor FROM configuracoes')->fetchAll() as $linha) {
            if (array_key_exists($linha['chave'], $config)) {
                $config[$linha['chave']] = is_numeric($linha['valor']) ? (float) $linha['valor'] : $linha['valor'];
            }
        }
    } catch (Throwable $erro) {}

    return $config;
}

function dificuldades_jogo(): array
{
    return \Sistema\Regras\CatalogoJogo::dificuldades();
}

function skins_jogo(): array
{
    return \Sistema\Regras\CatalogoJogo::skins();
}

function nivel_jogador(int $xp): array
{
    return \Sistema\Regras\Nivel::calcular($xp);
}

function missoes_do_dia(): array
{
    return \Sistema\Regras\CatalogoJogo::missoesDoDia();
}

function estatisticas_gerais(): array
{
    try {
        return (new \Sistema\Servicos\ServicoMetricas(pdo()))->gerais();
    } catch (Throwable $erro) {
        return ['partidas' => 0, 'jogadores' => 0, 'media' => 0, 'maior' => 0, 'fase' => 1, 'campeao' => 'MySQL offline', 'pontos_campeao' => 0, 'dificuldade' => 'normal', 'partidas_hoje' => 0, 'maior_hoje' => 0, 'jogadores_ativos' => 0, 'mais_ativo' => 'Aguardando', 'tempo_medio' => 0];
    }
}
