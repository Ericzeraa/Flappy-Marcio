<?php

function exportar_painel(string $tipo): void
{
    $tipo = $tipo === 'partidas' ? 'partidas' : 'ranking';
    $pdo = pdo();
    $arquivo = $tipo === 'partidas' ? 'historico_partidas.csv' : 'ranking_flappy_marcio.csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $arquivo . '"');

    $saida = fopen('php://output', 'w');
    fputcsv($saida, ['Flappy Márcio'], ';');
    fputcsv($saida, ['Feito por', 'Eric, Vinicius e Jhonatan'], ';');
    fputcsv($saida, ['Exportado em', date('d/m/Y H:i')], ';');
    fputcsv($saida, [], ';');
    fputcsv($saida, ['Jogador', 'Dificuldade', 'Pontos', 'Fase', 'Tempo', 'Velocidade', 'Data'], ';');

    if ($tipo === 'partidas') {
        $linhas = $pdo->query('SELECT j.nome, p.dificuldade, p.pontos, p.fase, p.duracao_seg, p.velocidade_final, p.criado_em data FROM partidas p JOIN jogadores j ON j.id = p.jogador_id ORDER BY p.criado_em DESC')->fetchAll();
    } else {
        $linhas = $pdo->query('SELECT j.nome, p.dificuldade, p.pontos, p.fase, p.duracao_seg, p.velocidade_final, p.atualizado_em data FROM pontuacoes p JOIN jogadores j ON j.id = p.jogador_id ORDER BY p.pontos DESC, p.atualizado_em ASC')->fetchAll();
    }

    foreach ($linhas as $linha) {
        fputcsv($saida, [$linha['nome'], $linha['dificuldade'], $linha['pontos'], $linha['fase'], $linha['duracao_seg'], $linha['velocidade_final'], $linha['data']], ';');
    }

    exit;
}
