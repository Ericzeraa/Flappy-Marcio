<?php

function usuario_limpo(string $usuario): string
{
    return \Sistema\Base\FiltroTexto::usuario($usuario);
}

function validar_usuario_senha(string $usuario, string $senha): ?string
{
    try {
        \Sistema\Base\Validador::usuarioSenha($usuario, $senha);
        return null;
    } catch (InvalidArgumentException $erro) {
        return $erro->getMessage();
    }
}

function buscar_jogador_por_id(int $id): array
{
    $stmt = pdo()->prepare('SELECT * FROM jogadores WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $jogador = $stmt->fetch();
    if (!$jogador) throw new RuntimeException('Jogador não encontrado.');
    return $jogador;
}

function jogador_sessao(): ?array
{
    \Sistema\Base\Sessao::start();
    $id = (int) ($_SESSION['jogador_id'] ?? 0);
    if (!$id) return null;
    try {
        return buscar_jogador_por_id($id);
    } catch (Throwable) {
        unset($_SESSION['jogador_id']);
        return null;
    }
}
