<?php

function resposta_json(array $dados, int $codigo = 200): void
{
    \Sistema\Base\RespostaJson::enviar($dados, $codigo);
}

function limpar_texto(?string $valor): string
{
    return \Sistema\Base\FiltroTexto::texto($valor);
}

function token_csrf(): string
{
    return \Sistema\Base\ProtecaoCsrf::token();
}

function validar_csrf(?string $token): bool
{
    return \Sistema\Base\ProtecaoCsrf::validar($token);
}

function campo_csrf(): string
{
    return \Sistema\Base\ProtecaoCsrf::campo();
}

function asset_v(string $caminho): string
{
    $arquivo = dirname(__DIR__) . '/' . ltrim($caminho, '/');
    $versao = is_file($arquivo) ? filemtime($arquivo) : time();
    return $caminho . '?v=' . $versao;
}

function data_br(?string $data): string
{
    return $data ? date('d/m/Y H:i', strtotime($data)) : '-';
}
