<?php

function pdo(): PDO
{
    return \Sistema\Base\Conexao::pdo('preparar_banco');
}

function coluna_existe(PDO $pdo, string $tabela, string $coluna): bool
{
    $stmt = $pdo->prepare('SELECT COUNT(*) total FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?');
    $stmt->execute([DB_NAME, $tabela, $coluna]);
    return (int) $stmt->fetchColumn() > 0;
}

function adicionar_coluna(PDO $pdo, string $tabela, string $coluna, string $sql): void
{
    if (!coluna_existe($pdo, $tabela, $coluna)) {
        $pdo->exec("ALTER TABLE {$tabela} ADD COLUMN {$sql}");
    }
}

function preparar_banco(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS jogadores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(50) NOT NULL,
        nome_chave VARCHAR(50) NOT NULL UNIQUE,
        senha_hash VARCHAR(255) NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        xp INT NOT NULL DEFAULT 0,
        skin VARCHAR(30) NOT NULL DEFAULT 'classica'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS partidas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        jogador_id INT NOT NULL,
        pontos INT NOT NULL DEFAULT 0,
        fase INT NOT NULL DEFAULT 1,
        duracao_seg DECIMAL(8,2) NOT NULL DEFAULT 0,
        velocidade_final DECIMAL(5,2) NOT NULL DEFAULT 1,
        dificuldade VARCHAR(20) NOT NULL DEFAULT 'normal',
        skin VARCHAR(30) NOT NULL DEFAULT 'classica',
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS pontuacoes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        jogador_id INT NOT NULL,
        dificuldade VARCHAR(20) NOT NULL DEFAULT 'normal',
        pontos INT NOT NULL DEFAULT 0,
        fase INT NOT NULL DEFAULT 1,
        duracao_seg DECIMAL(8,2) NOT NULL DEFAULT 0,
        velocidade_final DECIMAL(5,2) NOT NULL DEFAULT 1,
        atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY jogador_dificuldade (jogador_id, dificuldade),
        FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS conquistas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        jogador_id INT NOT NULL,
        codigo VARCHAR(60) NOT NULL,
        titulo VARCHAR(80) NOT NULL,
        descricao VARCHAR(160) NOT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY jogador_conquista (jogador_id, codigo),
        FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS missoes_concluidas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        jogador_id INT NOT NULL,
        codigo VARCHAR(60) NOT NULL,
        titulo VARCHAR(80) NOT NULL,
        data_ref DATE NOT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY jogador_missao (jogador_id, codigo, data_ref),
        FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS administradores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario VARCHAR(40) NOT NULL UNIQUE,
        senha_hash VARCHAR(255) NOT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS partidas_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        jogador_id INT NOT NULL,
        token CHAR(48) NOT NULL UNIQUE,
        dificuldade VARCHAR(20) NOT NULL DEFAULT 'normal',
        skin VARCHAR(30) NOT NULL DEFAULT 'classica',
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        usado_em DATETIME NULL,
        INDEX idx_token_jogador (jogador_id, token),
        INDEX idx_token_expiracao (criado_em, usado_em),
        FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $stmtAdmin = $pdo->prepare('SELECT id FROM administradores WHERE usuario = ? LIMIT 1');
    $stmtAdmin->execute([ADMIN_PADRAO_USUARIO]);
    if (!$stmtAdmin->fetch()) {
        $stmtAdmin = $pdo->prepare('INSERT INTO administradores (usuario, senha_hash) VALUES (?, ?)');
        $stmtAdmin->execute([ADMIN_PADRAO_USUARIO, \Sistema\Base\Autenticacao::gerarSenha(ADMIN_PADRAO_SENHA)]);
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS auditoria_eventos (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        evento VARCHAR(80) NOT NULL,
        jogador_id INT NULL,
        dados_json JSON NULL,
        ip VARCHAR(45) NULL,
        agente VARCHAR(180) NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_auditoria_evento (evento, criado_em),
        INDEX idx_auditoria_jogador (jogador_id, criado_em),
        FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS tentativas_acesso (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        chave_hash CHAR(40) NOT NULL,
        contexto VARCHAR(50) NOT NULL,
        ip VARCHAR(45) NOT NULL,
        criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_tentativas_chave (chave_hash, criado_em),
        INDEX idx_tentativas_limpeza (criado_em)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS configuracoes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        chave VARCHAR(60) NOT NULL UNIQUE,
        valor VARCHAR(120) NOT NULL,
        descricao VARCHAR(160) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    adicionar_coluna($pdo, 'jogadores', 'senha_hash', "senha_hash VARCHAR(255) NULL");
    adicionar_coluna($pdo, 'jogadores', 'xp', "xp INT NOT NULL DEFAULT 0");
    adicionar_coluna($pdo, 'jogadores', 'skin', "skin VARCHAR(30) NOT NULL DEFAULT 'classica'");
    adicionar_coluna($pdo, 'partidas', 'dificuldade', "dificuldade VARCHAR(20) NOT NULL DEFAULT 'normal'");
    adicionar_coluna($pdo, 'partidas', 'skin', "skin VARCHAR(30) NOT NULL DEFAULT 'classica'");
    adicionar_coluna($pdo, 'pontuacoes', 'dificuldade', "dificuldade VARCHAR(20) NOT NULL DEFAULT 'normal'");
    try { $pdo->exec('ALTER TABLE pontuacoes ADD INDEX jogador_fk_idx (jogador_id)'); } catch (Throwable $e) {}
    try { $pdo->exec('ALTER TABLE pontuacoes DROP INDEX jogador_id'); } catch (Throwable $e) {}
    try { $pdo->exec('ALTER TABLE pontuacoes ADD UNIQUE KEY jogador_dificuldade (jogador_id, dificuldade)'); } catch (Throwable $e) {}
    try { $pdo->exec('CREATE INDEX idx_partidas_data ON partidas (criado_em)'); } catch (Throwable $e) {}
    try { $pdo->exec('CREATE INDEX idx_partidas_dificuldade ON partidas (dificuldade)'); } catch (Throwable $e) {}
    try { $pdo->exec('CREATE INDEX idx_pontuacoes_ranking ON pontuacoes (pontos, atualizado_em)'); } catch (Throwable $e) {}

    $configs = [
        ['velocidade_inicial', '4.20', 'Velocidade inicial dos canos'],
        ['aumento_fase', '0.38', 'Aumento de velocidade a cada fase'],
        ['velocidade_maxima', '7.20', 'Limite de velocidade'],
        ['pontos_por_fase', '6', 'Pontos para mudar de fase'],
        ['abertura_inicial', '210', 'Espaço inicial entre canos'],
        ['abertura_minima', '168', 'Menor espaço entre canos'],
        ['gravidade', '0.46', 'Força da gravidade'],
        ['pulo', '-8.25', 'Força do pulo']
    ];

    $stmt = $pdo->prepare('INSERT IGNORE INTO configuracoes (chave, valor, descricao) VALUES (?, ?, ?)');
    foreach ($configs as $config) {
        $stmt->execute($config);
    }
}
