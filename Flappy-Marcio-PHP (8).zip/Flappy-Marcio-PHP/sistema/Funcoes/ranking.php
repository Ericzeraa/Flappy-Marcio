<?php

function auditar_evento(string $evento, ?int $jogadorId = null, array $dados = []): void
{
    try {
        $request = \Sistema\Base\Requisicao::capturar();
        (new \Sistema\Repositorios\RepositorioAuditoria(pdo()))->registrar($evento, $jogadorId, $dados, $request->ip(), $request->agente());
    } catch (Throwable) {}
}

function posicao_jogador(int $jogadorId, string $dificuldade = 'geral'): ?int
{
    $pdo = pdo();
    if ($dificuldade !== 'geral') {
        $stmt = $pdo->prepare('SELECT jogador_id FROM pontuacoes WHERE dificuldade = ? ORDER BY pontos DESC, atualizado_em ASC');
        $stmt->execute([$dificuldade]);
    } else {
        $stmt = $pdo->query('SELECT jogador_id FROM pontuacoes ORDER BY pontos DESC, atualizado_em ASC');
    }

    $posicao = 1;
    while ($linha = $stmt->fetch()) {
        if ((int) $linha['jogador_id'] === $jogadorId) {
            return $posicao;
        }
        $posicao++;
    }
    return null;
}

function conquistas_catalogo(): array
{
    return \Sistema\Regras\CatalogoJogo::conquistas();
}

function conquistas_jogador(int $jogadorId): array
{
    $stmt = pdo()->prepare('SELECT codigo, titulo, descricao, criado_em FROM conquistas WHERE jogador_id = ? ORDER BY criado_em DESC');
    $stmt->execute([$jogadorId]);
    return $stmt->fetchAll();
}

function perfil_jogador(int $jogadorId): array
{
    $pdo = pdo();
    $stmt = $pdo->prepare('SELECT COUNT(*) partidas, COALESCE(MAX(pontos),0) melhor, COALESCE(MAX(fase),1) fase, COALESCE(AVG(pontos),0) media, COALESCE(SUM(duracao_seg),0) tempo, COALESCE(SUM(pontos),0) pontos_total FROM partidas WHERE jogador_id = ?');
    $stmt->execute([$jogadorId]);
    $dados = $stmt->fetch() ?: [];

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM conquistas WHERE jogador_id = ?');
    $stmt->execute([$jogadorId]);
    $conquistas = (int) $stmt->fetchColumn();

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM missoes_concluidas WHERE jogador_id = ? AND data_ref = CURDATE()');
    $stmt->execute([$jogadorId]);
    $missoesHoje = (int) $stmt->fetchColumn();

    $partidas = (int) ($dados['partidas'] ?? 0);
    $melhor = (int) ($dados['melhor'] ?? 0);
    $fase = (int) ($dados['fase'] ?? 1);
    $pontosTotal = (int) ($dados['pontos_total'] ?? 0);
    $xp = ($partidas * 12) + ($pontosTotal * 4) + ($fase * 15) + ($conquistas * 30) + ($missoesHoje * 10);
    $nivel = nivel_jogador($xp);

    return [
        'partidas' => $partidas,
        'melhor' => $melhor,
        'fase' => $fase,
        'media' => round((float) ($dados['media'] ?? 0), 1),
        'tempo' => round((float) ($dados['tempo'] ?? 0), 1),
        'conquistas' => $conquistas,
        'missoesHoje' => $missoesHoje,
        'xp' => $nivel['xp'],
        'nivel' => $nivel['nivel'],
        'tituloNivel' => $nivel['titulo'],
        'xpAtual' => $nivel['atual'],
        'xpProximo' => $nivel['proximo']
    ];
}
