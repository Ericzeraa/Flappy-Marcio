<?php
require_once __DIR__ . '/sistema/funcoes_gerais.php';

$ok = false;
$erro = '';

try {
    pdo();
    $ok = true;
} catch (Throwable $e) {
    $erro = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Flappy Márcio</title>
    <link rel="stylesheet" href="arquivos/estilos/estilo.css">
</head>
<body class="pagina-setup">
    <main class="setup-card">
        <span class="tag">Configuração</span>
        <h1>Flappy Márcio</h1>
        <?php if ($ok): ?>
            <p>Banco pronto. Abra o jogo e, se precisar, acesse o painel com admin / marcio@2026.</p>
            <a class="link-setup" href="index.php">Abrir jogo</a>
            <a class="link-setup secundario" href="painel.php">Abrir painel</a>
        <?php else: ?>
            <p>Não consegui preparar o banco de dados.</p>
            <pre><?= htmlspecialchars($erro) ?></pre>
            <p>Veja se o MySQL do XAMPP está ligado e confira os dados em <strong>configuracao/banco.php</strong>.</p>
        <?php endif; ?>
    </main>
</body>
</html>
