<?php
require_once __DIR__ . '/sistema/funcoes_gerais.php';
\Sistema\Base\Sessao::start();
\Sistema\Base\CabecalhoSeguro::segurancaBasica();

$mensagem = '';
$erro = '';
$painelAdmin = null;
$baseTelas = __DIR__ . '/telas/painel/';

try {
    $painelAdmin = new PainelAdministrativo();
} catch (Throwable $e) {
    $erro = $e->getMessage();
}

if (isset($_GET['sair'])) {
    auditar_evento('logout_admin', null, []);
    unset($_SESSION['admin_logado']);
    header('Location: painel.php');
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && ($_POST['acao'] ?? '') === 'login_admin') {
    $usuario = trim($_POST['usuario'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if (!validar_csrf($_POST['csrf_token'] ?? null)) {
        $erro = 'Sessão expirada. Recarregue a página e tente novamente.';
    } elseif ($painelAdmin && $painelAdmin->autenticar($usuario, $senha)) {
        \Sistema\Base\Sessao::renovar();
        auditar_evento('login_admin', null, ['usuario' => $usuario]);
        $_SESSION['admin_logado'] = true;
        header('Location: painel.php');
        exit;
    } else {
        $erro = 'Usuário ou senha incorretos.';
    }
}

if (empty($_SESSION['admin_logado'])) {
    require $baseTelas . 'login.php';
    exit;
}

if (isset($_GET['exportar'])) {
    exportar_painel((string) $_GET['exportar']);
}

try {
    if (!$painelAdmin) {
        throw new RuntimeException($erro ?: 'Painel indisponível no momento.');
    }

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        if (!validar_csrf($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException('Sessão expirada. Recarregue a página e tente novamente.');
        }

        $acao = $_POST['acao'] ?? '';

        if ($acao === 'salvar_config') {
            $painelAdmin->salvarConfiguracoes($_POST);
            auditar_evento('admin_salvou_configuracoes', null, ['chaves' => array_keys($_POST)]);
            $mensagem = 'Configurações salvas. Agora é testar para ver quem reclama primeiro.';
        }

        if ($acao === 'limpar_ranking') {
            $painelAdmin->limparRanking();
            auditar_evento('admin_limpou_ranking', null, []);
            $mensagem = 'Ranking e histórico limpos. Zerou tudo, até a vergonha das quedas.';
        }

        if ($acao === 'excluir_jogador') {
            $id = filter_input(INPUT_POST, 'jogador_id', FILTER_VALIDATE_INT);
            if ($id) {
                $painelAdmin->excluirJogador($id);
                auditar_evento('admin_excluiu_jogador', $id, []);
                $mensagem = 'Jogador removido do jogo.';
            }
        }
    }

    $stats = estatisticas_gerais();
    $configs = configuracoes_jogo();
    $dadosPainel = $painelAdmin->dadosPainel();
    $ranking = $dadosPainel['ranking'];
    $partidas = $dadosPainel['partidas'];
    $conquistas = $dadosPainel['conquistas'];
    $missoes = $dadosPainel['missoes'];
    $porDificuldade = $dadosPainel['porDificuldade'];
    $auditoria = $dadosPainel['auditoria'] ?? [];
    $indicadoresTecnicos = $dadosPainel['indicadoresTecnicos'] ?? [];
} catch (Throwable $e) {
    $erro = $e->getMessage();
    $stats = estatisticas_gerais();
    $configs = configuracoes_jogo();
    $ranking = $partidas = $conquistas = $missoes = $porDificuldade = [];
    $auditoria = [];
    $indicadoresTecnicos = [];
}

require $baseTelas . 'inicio.php';
require $baseTelas . 'topo.php';
require $baseTelas . 'avisos.php';
require $baseTelas . 'estatisticas.php';
require $baseTelas . 'ranking.php';
require $baseTelas . 'indicadores.php';
require $baseTelas . 'auditoria.php';
require $baseTelas . 'configuracoes.php';
require $baseTelas . 'desempenho.php';
require $baseTelas . 'historico.php';
require $baseTelas . 'conquistas.php';
require $baseTelas . 'missoes.php';
require $baseTelas . 'limpar.php';
require $baseTelas . 'fim.php';
